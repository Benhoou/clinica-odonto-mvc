<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Csrf;
use App\Core\Flash;
use App\Models\PacienteRepository;

final class PacientesController
{
    private PacienteRepository $repo;

    public function __construct()
    {
        $this->repo = new PacienteRepository();
    }

    /** GET /pacientes */
    public function index(Request $req): string
    {
        $q    = isset($req->query['q']) ? trim((string)$req->query['q']) : '';
        $page = max(1, (int)($req->query['page'] ?? 1));
        $sort = (string)($req->query['sort'] ?? 'created_at');
        $dir  = (string)($req->query['dir']  ?? 'desc');

        [$items, $total] = $this->repo->paginate($q, $sort, $dir, $page, 10);
        $totalPages = max(1, (int)ceil($total / 10));

        view('pacientes/index', [
            'title'      => 'Pacientes',
            'base'       => BASE_URL,
            'items'      => $items,
            'total'      => $total,
            'q'          => $q,
            'page'       => $page,
            'sort'       => $sort,
            'dir'        => $dir,
            'totalPages' => $totalPages,
        ]);

        return '';
    }

    /** GET /pacientes/create */
    public function create(Request $req): string
    {
        $paciente = [
            'id' => null,
            'nome' => '',
            'email' => '',
            'telefone' => '',
            'data_nascimento' => '',
            'cpf' => '',
            'endereco' => '',
            'observacoes' => '',
        ];

        view('pacientes/form', [
            'title'    => 'Novo Paciente',
            'base'     => BASE_URL,
            'paciente' => $paciente,
            'errors'   => [],
        ]);

        return '';
    }

    /** POST /pacientes/store */
    public function store(Request $req): string
    {
        // CSRF
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/pacientes');
            exit;
        }

        $data = [
            'nome'            => trim((string)$req->post['nome'] ?? ''),
            'email'           => trim((string)$req->post['email'] ?? ''),
            'telefone'        => trim((string)$req->post['telefone'] ?? ''),
            'data_nascimento' => trim((string)$req->post['data_nascimento'] ?? ''),
            'cpf'             => trim((string)$req->post['cpf'] ?? ''),
            'endereco'        => trim((string)$req->post['endereco'] ?? ''),
            'observacoes'     => trim((string)$req->post['observacoes'] ?? ''),
        ];

        // Validações simples (exemplo)
        $errors = [];
        if ($data['nome'] === '') {
            $errors['nome'] = 'Nome é obrigatório.';
        }
        if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'E-mail inválido.';
        }

        if ($errors) {
            view('pacientes/form', [
                'title'    => 'Novo Paciente',
                'base'     => BASE_URL,
                'paciente' => $data + ['id' => null],
                'errors'   => $errors,
            ]);
            return '';
        }

        [$ok, $res] = $this->repo->insert($data);
        if ($ok) {
            Flash::set('success', 'Paciente cadastrado com sucesso.');
            header('Location: ' . BASE_URL . '/pacientes');
            exit;
        }

        Flash::set('error', (string)$res);
        header('Location: ' . BASE_URL . '/pacientes');
        exit;
    }

    /** GET /pacientes/edit?id= */
    public function edit(Request $req): string
{
    $id = (int)($req->query['id'] ?? 0);
    if ($id <= 0) {
        \App\Core\Flash::set('error', 'ID inválido.');
        header('Location: ' . BASE_URL . '/pacientes');
        exit;
    }

    $paciente = $this->repo->find($id);
    if (!$paciente) {
        \App\Core\Flash::set('error', 'Paciente não encontrado.');
        header('Location: ' . BASE_URL . '/pacientes');
        exit;
    }

    $title  = 'Editar Paciente';
    $errors = [];

    ob_start();
    include APP_PATH . '/Views/pacientes/form.php';
    $content = (string)ob_get_clean();

    ob_start();
    include APP_PATH . '/Views/layout.php';
    return (string)ob_get_clean();
}

    /** POST /pacientes/update */
    public function update(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/pacientes');
            exit;
        }

        $id = (int)($req->post['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/pacientes');
            exit;
        }

        $data = [
            'nome'            => trim((string)$req->post['nome'] ?? ''),
            'email'           => trim((string)$req->post['email'] ?? ''),
            'telefone'        => trim((string)$req->post['telefone'] ?? ''),
            'data_nascimento' => trim((string)$req->post['data_nascimento'] ?? ''),
            'cpf'             => trim((string)$req->post['cpf'] ?? ''),
            'endereco'        => trim((string)$req->post['endereco'] ?? ''),
            'observacoes'     => trim((string)$req->post['observacoes'] ?? ''),
        ];

        $errors = [];
        if ($data['nome'] === '') {
            $errors['nome'] = 'Nome é obrigatório.';
        }
        if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'E-mail inválido.';
        }

        if ($errors) {
            view('pacientes/form', [
                'title'    => 'Editar Paciente',
                'base'     => BASE_URL,
                'paciente' => $data + ['id' => $id],
                'errors'   => $errors,
            ]);
            return '';
        }

        [$ok, $res] = $this->repo->update($id, $data);
        if ($ok) {
            Flash::set('success', 'Paciente atualizado com sucesso.');
            header('Location: ' . BASE_URL . '/pacientes');
            exit;
        }

        Flash::set('error', (string)$res);
        header('Location: ' . BASE_URL . '/pacientes');
        exit;
    }

    /** POST /pacientes/delete */
    public function delete(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/pacientes');
            exit;
        }

        $id = (int)($req->post['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/pacientes');
            exit;
        }

        [$ok, $res] = $this->repo->delete($id);
        if ($ok) {
            Flash::set('success', 'Paciente excluído com sucesso.');
        } else {
            Flash::set('error', (string)$res);
        }

        header('Location: ' . BASE_URL . '/pacientes');
        exit;
    }

    /** GET /pacientes/export */
    public function export(Request $req): string
    {
        // permanece como você já tinha
        require_once APP_PATH . '/Core/Csv.php';

        $q    = isset($req->query['q']) ? trim((string)$req->query['q']) : '';
        $sort = (string)($req->query['sort'] ?? 'created_at');
        $dir  = (string)($req->query['dir']  ?? 'desc');

        $rows = $this->repo->listFiltered($q, $sort, $dir);

        $headers = ['ID', 'Nome', 'E-mail', 'Telefone', 'Data de nascimento', 'CPF', 'Criado em'];
        $data = array_map(function (array $r) {
            return [
                'id'                 => $r['id'],
                'nome'               => $r['nome'],
                'email'              => $r['email'],
                'telefone'           => $r['telefone'],
                'data_de_nascimento' => $r['data_nascimento'],
                'cpf'                => $r['cpf'],
                'criado_em'          => $r['created_at'],
            ];
        }, $rows);

        \App\Core\Csv::download('pacientes_' . date('Y-m-d_H-i-s') . '.csv', $headers, $data);
        return '';
    }
}
