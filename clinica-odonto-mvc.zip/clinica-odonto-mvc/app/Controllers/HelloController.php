<?php
declare(strict_types=1);

namespace App\Controllers;

final class HelloController
{
    public function message(): string
    {
        return 'Hello Controller — Autoload OK — ' . date('Y-m-d H:i:s');
    }
}
