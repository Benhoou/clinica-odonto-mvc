<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Csrf;
use App\Core\Flash;
use App\Models\ConsultaRepository;

final class ConsultasController
{
    private ConsultaRepository $repo;

    public function __construct()
    {
        $this->repo = new ConsultaRepository();
    }

    /**
     * GET /consultas
     * Lista com busca/ordenação/paginação
     */
    public function index(Request $req): string
    {
        // 🔧 Garantimos que $q seja SEMPRE string (evita null passando para o repo)
        $q    = isset($req->query['q']) ? trim((string)$req->query['q']) : '';
        $page = max(1, (int)($req->query['page'] ?? 1));
        $sort = (string)($req->query['sort'] ?? 'data_hora');
        $dir  = (string)($req->query['dir']  ?? 'asc');

        // Carrega lista + total
        [$items, $total] = $this->repo->paginate($q, $sort, $dir, $page, 10);
        $totalPages = max(1, (int)ceil($total / 10));

        $title = 'Consultas';

        // Render da view da página
        ob_start();
        include APP_PATH . '/Views/consultas/index.php';
        $content = (string)ob_get_clean();

        ob_start();
        include APP_PATH . '/Views/layout.php';
        return (string)ob_get_clean();
    }

    /**
     * GET /consultas/create
     */
    public function create(Request $req): string
    {
        $title = 'Nova Consulta';
        $consulta = [
            'id' => null,
            'paciente_id' => null,
            'dentista_id' => null,
            'procedimento_id' => null,
            'data_hora' => '',
            'status' => 'agendada',
            'observacoes' => '',
            'valor_cobrado' => null,
        ];
        $errors = [];

        ob_start();
        include APP_PATH . '/Views/consultas/form.php';
        $content = (string)ob_get_clean();

        ob_start();
        include APP_PATH . '/Views/layout.php';
        return (string)ob_get_clean();
    }

    /**
     * POST /consultas/store
     */
    public function store(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }

        $data = [
            'paciente_id'     => (int)($req->post['paciente_id'] ?? 0),
            'dentista_id'     => (int)($req->post['dentista_id'] ?? 0),
            'procedimento_id' => (int)($req->post['procedimento_id'] ?? 0),
            'data_hora'       => trim((string)($req->post['data_hora'] ?? '')),
            'status'          => trim((string)($req->post['status'] ?? 'agendada')),
            'observacoes'     => trim((string)($req->post['observacoes'] ?? '')),
            'valor_cobrado'   => ($req->post['valor_cobrado'] ?? '') !== '' ? (float)$req->post['valor_cobrado'] : null,
        ];

        $errors = [];
        if ($data['paciente_id'] <= 0)     $errors['paciente_id']     = 'Paciente é obrigatório.';
        if ($data['dentista_id'] <= 0)     $errors['dentista_id']     = 'Dentista é obrigatório.';
        if ($data['procedimento_id'] <= 0) $errors['procedimento_id'] = 'Procedimento é obrigatório.';
        if ($data['data_hora'] === '')     $errors['data_hora']       = 'Data/Hora é obrigatória.';

        if ($errors) {
            $title = 'Nova Consulta';
            $consulta = $data + ['id' => null];
            ob_start(); include APP_PATH . '/Views/consultas/form.php'; $content = (string)ob_get_clean();
            ob_start(); include APP_PATH . '/Views/layout.php'; return (string)ob_get_clean();
        }

        [$ok, $res] = $this->repo->insert($data);
        if ($ok) {
            Flash::set('success', 'Consulta cadastrada com sucesso.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }
        Flash::set('error', (string)$res);
        header('Location: ' . BASE_URL . '/consultas');
        exit;
    }

    /**
     * GET /consultas/edit?id=
     */
    public function edit(Request $req): string
    {
        $id = (int)($req->query['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }

        $consulta = $this->repo->find($id);
        if (!$consulta) {
            Flash::set('error', 'Consulta não encontrada.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }

        $title = 'Editar Consulta';
        $errors = [];

        ob_start();
        include APP_PATH . '/Views/consultas/form.php';
        $content = (string)ob_get_clean();

        ob_start();
        include APP_PATH . '/Views/layout.php';
        return (string)ob_get_clean();
    }

    /**
     * POST /consultas/update
     */
    public function update(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }

        $id = (int)($req->post['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }

        $data = [
            'paciente_id'     => (int)($req->post['paciente_id'] ?? 0),
            'dentista_id'     => (int)($req->post['dentista_id'] ?? 0),
            'procedimento_id' => (int)($req->post['procedimento_id'] ?? 0),
            'data_hora'       => trim((string)($req->post['data_hora'] ?? '')),
            'status'          => trim((string)($req->post['status'] ?? 'agendada')),
            'observacoes'     => trim((string)($req->post['observacoes'] ?? '')),
            'valor_cobrado'   => ($req->post['valor_cobrado'] ?? '') !== '' ? (float)$req->post['valor_cobrado'] : null,
        ];

        $errors = [];
        if ($data['paciente_id'] <= 0)     $errors['paciente_id']     = 'Paciente é obrigatório.';
        if ($data['dentista_id'] <= 0)     $errors['dentista_id']     = 'Dentista é obrigatório.';
        if ($data['procedimento_id'] <= 0) $errors['procedimento_id'] = 'Procedimento é obrigatório.';
        if ($data['data_hora'] === '')     $errors['data_hora']       = 'Data/Hora é obrigatória.';

        if ($errors) {
            $title = 'Editar Consulta';
            $consulta = $data + ['id' => $id];
            ob_start(); include APP_PATH . '/Views/consultas/form.php'; $content = (string)ob_get_clean();
            ob_start(); include APP_PATH . '/Views/layout.php'; return (string)ob_get_clean();
        }

        [$ok, $res] = $this->repo->update($id, $data);
        if ($ok) {
            Flash::set('success', 'Consulta atualizada com sucesso.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }
        Flash::set('error', (string)$res);
        header('Location: ' . BASE_URL . '/consultas');
        exit;
    }

    /**
     * POST /consultas/delete
     */
    public function delete(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }

        $id = (int)($req->post['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/consultas');
            exit;
        }

        [$ok, $res] = $this->repo->delete($id);
        if ($ok) {
            Flash::set('success', 'Consulta excluída com sucesso.');
        } else {
            Flash::set('error', (string)$res);
        }
        header('Location: ' . BASE_URL . '/consultas');
        exit;
    }

    /**
     * (Opcional) export CSV, se você já usa
     */
    public function export(Request $req): string
    {
        require_once APP_PATH . '/Core/Csv.php';

        $q    = isset($req->query['q']) ? trim((string)$req->query['q']) : '';
        $sort = (string)($req->query['sort'] ?? 'data_hora');
        $dir  = (string)($req->query['dir']  ?? 'asc');

        $rows = $this->repo->listFiltered($q, $sort, $dir);

        $headers = ['ID','Data/Hora','Paciente','Dentista','Procedimento','Status','Valor'];
        $data = array_map(function(array $r) {
            return [
                'id'            => $r['id'],
                'data_hora'     => $r['data_hora'],
                'paciente'      => $r['paciente'],
                'dentista'      => $r['dentista'],
                'procedimento'  => $r['procedimento'],
                'status'        => $r['status'],
                'valor'         => $r['valor_cobrado'],
            ];
        }, $rows);

        \App\Core\Csv::download('consultas_' . date('Y-m-d_H-i-s') . '.csv', $headers, $data);
        return '';
    }
}
