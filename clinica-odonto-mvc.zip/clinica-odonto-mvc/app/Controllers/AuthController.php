<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Flash;
use App\Models\UserRepository;

final class AuthController
{
    /** GET /login */
    public function showLogin(Request $req): string
    {
        \view('auth/login', [
            'title' => 'Entrar',
            'msg'   => Flash::pull('success') ?? '',
            'err'   => Flash::pull('error')   ?? '',
            'email' => (string)($req->query['email'] ?? ''),
        ]);
        return '';
    }

    /** POST /login */
    public function login(Request $req): string
    {
        if (!\csrf_check()) {
            Flash::set('error', 'Falha de segurança (CSRF).');
            header('Location: ' . BASE_URL . '/login');
            exit;
        }

        $email = trim((string)($req->post['email'] ?? ''));
        $pass  = (string)($req->post['password'] ?? '');

        if ($email === '' || $pass === '') {
            Flash::set('error', 'Informe e-mail e senha.');
            header('Location: ' . BASE_URL . '/login?email=' . rawurlencode($email));
            exit;
        }

        $repo = new UserRepository();
        $user = $repo->findByEmail($email);

        if (!$user || !\password_verify($pass, (string)$user['senha_hash'])) {
            Flash::set('error', 'Credenciais inválidas.');
            header('Location: ' . BASE_URL . '/login?email=' . rawurlencode($email));
            exit;
        }

        $_SESSION['user'] = [
            'id'    => (int)$user['id'],
            'name'  => (string)($user['nome'] ?? 'Usuário'),
            'email' => (string)$user['email'],
            'role'  => (string)($user['role'] ?? 'admin'),
        ];

        Flash::set('success', 'Bem-vindo!');
        header('Location: ' . BASE_URL . '/');
        exit;
    }

    /** POST /logout */
    public function logout(Request $req): string
    {
        if (!\csrf_check()) {
            Flash::set('error', 'Falha de segurança (CSRF).');
            header('Location: ' . BASE_URL . '/login');
            exit;
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        Flash::set('success', 'Sessão encerrada.');
        header('Location: ' . BASE_URL . '/login');
        exit;
    }
}
