<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Csrf;
use App\Core\Flash;
use App\Models\DentistaRepository;

final class DentistasController
{
    private DentistaRepository $repo;

    public function __construct()
    {
        $this->repo = new DentistaRepository();
    }

    /** GET /dentistas */
    public function index(Request $req): string
    {
        $q    = isset($req->query['q']) ? trim((string)$req->query['q']) : '';
        $page = max(1, (int)($req->query['page'] ?? 1));
        $sort = (string)($req->query['sort'] ?? 'created_at');
        $dir  = (string)($req->query['dir']  ?? 'desc');

        [$items, $total] = $this->repo->paginate($q, $sort, $dir, $page, 10);
        $totalPages = max(1, (int)ceil($total / 10));

        $title = 'Dentistas';

        ob_start();
        $items      = $items;
        $total      = $total;
        $totalPages = $totalPages;
        $q          = $q;
        $page       = $page;
        $sort       = $sort;
        $dir        = $dir;
        include APP_PATH.'/Views/dentistas/index.php';
        $content = (string)ob_get_clean();

        ob_start();
        include APP_PATH.'/Views/layout.php';
        return (string)ob_get_clean();
    }

    /** GET /dentistas/create */
    public function create(Request $req): string
    {
        $title = 'Novo Dentista';
        $dentista = [
            'id'            => null,
            'nome'          => '',
            'email'         => '',
            'telefone'      => '',
            'cro'           => '',
            'especialidade' => '',
        ];
        $errors = [];
        $isEdit = false;

        ob_start();
        include APP_PATH.'/Views/dentistas/form.php';
        $content = (string)ob_get_clean();

        ob_start();
        include APP_PATH.'/Views/layout.php';
        return (string)ob_get_clean();
    }

    /** POST /dentistas/store */
    public function store(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        $data = [
            'nome'          => trim((string)$req->post['nome'] ?? ''),
            'email'         => trim((string)$req->post['email'] ?? ''),
            'telefone'      => trim((string)$req->post['telefone'] ?? ''),
            'cro'           => trim((string)$req->post['cro'] ?? ''),
            'especialidade' => trim((string)$req->post['especialidade'] ?? ''),
        ];

        $errors = [];
        if ($data['nome'] === '') {
            $errors['nome'] = 'Nome é obrigatório.';
        }
        if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'E-mail inválido.';
        }

        if ($errors) {
            $title = 'Novo Dentista';
            $dentista = $data + ['id' => null];
            $isEdit = false;

            ob_start();
            include APP_PATH.'/Views/dentistas/form.php';
            $content = (string)ob_get_clean();

            ob_start();
            include APP_PATH.'/Views/layout.php';
            return (string)ob_get_clean();
        }

        [$ok, $res] = $this->repo->insert($data);
        if ($ok) {
            Flash::set('success', 'Dentista cadastrado com sucesso.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        Flash::set('error', (string)$res);
        header('Location: ' . BASE_URL . '/dentistas');
        exit;
    }

    /** GET /dentistas/edit?id= */
    public function edit(Request $req): string
    {
        $id = (int)($req->query['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        $dentista = $this->repo->find($id);
        if (!$dentista) {
            Flash::set('error', 'Dentista não encontrado.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        $title  = 'Editar Dentista';
        $errors = [];
        $isEdit = true;

        ob_start();
        include APP_PATH.'/Views/dentistas/form.php';
        $content = (string)ob_get_clean();

        ob_start();
        include APP_PATH.'/Views/layout.php';
        return (string)ob_get_clean();
    }

    /** POST /dentistas/update */
    public function update(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        $id = (int)($req->post['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        $data = [
            'nome'          => trim((string)$req->post['nome'] ?? ''),
            'email'         => trim((string)$req->post['email'] ?? ''),
            'telefone'      => trim((string)$req->post['telefone'] ?? ''),
            'cro'           => trim((string)$req->post['cro'] ?? ''),
            'especialidade' => trim((string)$req->post['especialidade'] ?? ''),
        ];

        $errors = [];
        if ($data['nome'] === '') {
            $errors['nome'] = 'Nome é obrigatório.';
        }
        if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'E-mail inválido.';
        }

        if ($errors) {
            $title    = 'Editar Dentista';
            $dentista = $data + ['id' => $id];
            $isEdit   = true;

            ob_start();
            include APP_PATH.'/Views/dentistas/form.php';
            $content = (string)ob_get_clean();

            ob_start();
            include APP_PATH.'/Views/layout.php';
            return (string)ob_get_clean();
        }

        [$ok, $res] = $this->repo->update($id, $data);
        if ($ok) {
            Flash::set('success', 'Dentista atualizado com sucesso.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        Flash::set('error', (string)$res);
        header('Location: ' . BASE_URL . '/dentistas');
        exit;
    }

    /** POST /dentistas/delete */
    public function delete(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        $id = (int)($req->post['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/dentistas');
            exit;
        }

        [$ok, $res] = $this->repo->delete($id);
        if ($ok) {
            Flash::set('success', 'Dentista excluído com sucesso.');
        } else {
            Flash::set('error', (string)$res);
        }

        header('Location: ' . BASE_URL . '/dentistas');
        exit;
    }
}
