<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\DB;

final class HomeController
{
    public function index(Request $req): string
    {
        $pdo = DB::conn();

        // Contagens rápidas
        $q = fn(string $sql) => (int)$pdo->query($sql)->fetchColumn();

        $stats = [
            'pacientes'     => $q("SELECT COUNT(*) FROM pacientes"),
            'dentistas'     => $q("SELECT COUNT(*) FROM dentistas"),
            'procedimentos' => $q("SELECT COUNT(*) FROM procedimentos"),
            'hoje'          => $q("SELECT COUNT(*) FROM consultas WHERE DATE(data_hora) = CURDATE()"),
        ];

        // Consultas próximas (próximas 8)
        $stmt = $pdo->prepare("
            SELECT 
                c.id, c.data_hora, c.status,
                p.nome AS paciente, d.nome AS dentista, pr.nome AS procedimento
            FROM consultas c
            JOIN pacientes p     ON p.id  = c.paciente_id
            JOIN dentistas d     ON d.id  = c.dentista_id
            JOIN procedimentos pr ON pr.id = c.procedimento_id
            WHERE c.data_hora >= NOW()
            ORDER BY c.data_hora ASC
            LIMIT 8
        ");
        $stmt->execute();
        $proximas = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?: [];

        // Alertas simples (ex.: pendentes)
        $pendentes = $q("SELECT COUNT(*) FROM consultas WHERE status = 'pendente'");

        view('home/index', [
            'title'     => 'Início',
            'base'      => BASE_URL,
            'stats'     => $stats,
            'proximas'  => $proximas,
            'pendentes' => $pendentes,
        ]);

        return '';
    }
}
