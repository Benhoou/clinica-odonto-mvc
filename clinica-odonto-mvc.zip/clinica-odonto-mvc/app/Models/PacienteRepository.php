<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\DB;
use PDO;
use Throwable;

final class PacienteRepository
{
    private PDO $pdo;

    public function __construct()
    {
        // <- aqui estava DB::pdo()
        $this->pdo = DB::conn();
    }

    public function find(int $id): ?array
    {
        $sql = 'SELECT * FROM pacientes WHERE id = ? LIMIT 1';
        $st  = $this->pdo->prepare($sql);
        $st->execute([$id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function paginate(?string $q, string $sort, string $dir, int $page, int $perPage = 10): array
    {
        $q    = trim((string)($q ?? ''));
        $page = max(1, $page);
        $perPage = max(1, $perPage);

        $sort = $this->sanitizeSort($sort);
        $dir  = strtolower($dir) === 'asc' ? 'asc' : 'desc';

        [$where, $params] = $this->buildSearch($q);

        $stCount = $this->pdo->prepare("SELECT COUNT(*) FROM pacientes {$where}");
        $stCount->execute($params);
        $total = (int)$stCount->fetchColumn();

        $offset = ($page - 1) * $perPage;

        $sql = "SELECT * FROM pacientes {$where} ORDER BY {$sort} {$dir} LIMIT :limit OFFSET :offset";
        $st  = $this->pdo->prepare($sql);
        foreach ($params as $i => $val) {
            $st->bindValue($i + 1, $val, PDO::PARAM_STR);
        }
        $st->bindValue(':limit',  $perPage, PDO::PARAM_INT);
        $st->bindValue(':offset', $offset,  PDO::PARAM_INT);
        $st->execute();

        return [$st->fetchAll(PDO::FETCH_ASSOC) ?: [], $total];
    }

    public function listFiltered(?string $q, string $sort, string $dir): array
    {
        $q    = trim((string)($q ?? ''));
        $sort = $this->sanitizeSort($sort);
        $dir  = strtolower($dir) === 'asc' ? 'asc' : 'desc';

        [$where, $params] = $this->buildSearch($q);

        $st = $this->pdo->prepare("SELECT * FROM pacientes {$where} ORDER BY {$sort} {$dir}");
        $st->execute($params);

        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function insert(array $data): array
    {
        try {
            $sql = "INSERT INTO pacientes
                        (nome, email, telefone, data_nascimento, cpf, endereco, observacoes, created_at, updated_at)
                    VALUES
                        (:nome, :email, :telefone, :data_nascimento, :cpf, :endereco, :observacoes, NOW(), NOW())";
            $st = $this->pdo->prepare($sql);
            $st->execute([
                ':nome'            => (string)($data['nome'] ?? ''),
                ':email'           => (string)($data['email'] ?? ''),
                ':telefone'        => (string)($data['telefone'] ?? ''),
                ':data_nascimento' => (string)($data['data_nascimento'] ?? ''),
                ':cpf'             => (string)($data['cpf'] ?? ''),
                ':endereco'        => (string)($data['endereco'] ?? ''),
                ':observacoes'     => (string)($data['observacoes'] ?? ''),
            ]);

            return [true, (int)$this->pdo->lastInsertId()];
        } catch (Throwable $e) {
            return [false, $e->getMessage()];
        }
    }

    public function update(int $id, array $data): array
    {
        try {
            $sql = "UPDATE pacientes
                       SET nome = :nome,
                           email = :email,
                           telefone = :telefone,
                           data_nascimento = :data_nascimento,
                           cpf = :cpf,
                           endereco = :endereco,
                           observacoes = :observacoes,
                           updated_at = NOW()
                     WHERE id = :id";
            $st = $this->pdo->prepare($sql);
            $st->execute([
                ':id'              => $id,
                ':nome'            => (string)($data['nome'] ?? ''),
                ':email'           => (string)($data['email'] ?? ''),
                ':telefone'        => (string)($data['telefone'] ?? ''),
                ':data_nascimento' => (string)($data['data_nascimento'] ?? ''),
                ':cpf'             => (string)($data['cpf'] ?? ''),
                ':endereco'        => (string)($data['endereco'] ?? ''),
                ':observacoes'     => (string)($data['observacoes'] ?? ''),
            ]);

            return [true, $st->rowCount()];
        } catch (Throwable $e) {
            return [false, $e->getMessage()];
        }
    }

    public function delete(int $id): array
    {
        try {
            $st = $this->pdo->prepare('DELETE FROM pacientes WHERE id = ?');
            $st->execute([$id]);
            return [true, $st->rowCount()];
        } catch (Throwable $e) {
            return [false, $e->getMessage()];
        }
    }

    private function buildSearch(string $q): array
    {
        if ($q === '') {
            return ['', []];
        }
        $where  = 'WHERE (nome LIKE ? OR email LIKE ? OR telefone LIKE ? OR cpf LIKE ? OR endereco LIKE ?)';
        $like   = '%' . $q . '%';
        $params = [$like, $like, $like, $like, $like];
        return [$where, $params];
    }

    private function sanitizeSort(string $sort): string
    {
        $whitelist = [
            'id','nome','email','telefone','data_nascimento','cpf','created_at','updated_at',
        ];
        $sort = strtolower($sort);
        return in_array($sort, $whitelist, true) ? $sort : 'created_at';
    }
}
