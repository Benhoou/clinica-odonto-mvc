<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\DB;
use PDO;
use PDOException;

final class DentistaRepository
{
    private PDO $pdo;
    public function __construct()
    {
        $this->pdo = DB::conn();
    }

    /** Lista paginada com busca e ordenação. Retorna [items, total]. */
    public function paginate(
        ?string $q,
        string $sort,
        string $dir,
        int $page,
        int $perPage = 10
    ): array {
        $allowedSort = ['nome','email','telefone','cro','especialidade','created_at'];
        if (!in_array($sort, $allowedSort, true)) $sort = 'created_at';
        $dir = (strtolower($dir) === 'asc') ? 'ASC' : 'DESC';

        $where = '';
        $params = [];
        if ($q !== null && $q !== '') {
            $where = "WHERE (nome LIKE :q OR email LIKE :q OR telefone LIKE :q OR cro LIKE :q OR especialidade LIKE :q)";
            $params[':q'] = '%'.$q.'%';
        }

        $offset = max(0, ($page - 1) * $perPage);

        $sqlCount = "SELECT COUNT(*) FROM dentistas $where";
        $stmt = $this->pdo->prepare($sqlCount);
        $stmt->execute($params);
        $total = (int)$stmt->fetchColumn();

        $sql = "SELECT id, nome, email, telefone, cro, especialidade, created_at
                FROM dentistas
                $where
                ORDER BY $sort $dir
                LIMIT :limit OFFSET :offset";
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $k => $v) { $stmt->bindValue($k, $v); }
        $stmt->bindValue(':limit',  $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset,  PDO::PARAM_INT);
        $stmt->execute();
        $items = $stmt->fetchAll();

        return [$items, $total];
    }

    public function find(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM dentistas WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Retorna [ok, id|errorMessage] */
    public function insert(array $data): array
    {
        try {
            $sql = "INSERT INTO dentistas (nome, email, telefone, cro, especialidade)
                    VALUES (:nome, :email, :telefone, :cro, :especialidade)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':nome' => $data['nome'],
                ':email' => $data['email'] ?: null,
                ':telefone' => $data['telefone'] ?: null,
                ':cro' => $data['cro'] ?: null,
                ':especialidade' => $data['especialidade'] ?: null,
            ]);
            return [true, (int)$this->pdo->lastInsertId()];
        } catch (PDOException $e) {
            return [false, $this->friendlyError($e)];
        }
    }

    /** Retorna [ok, rows|errorMessage] */
    public function update(int $id, array $data): array
    {
        try {
            $sql = "UPDATE dentistas SET
                nome = :nome,
                email = :email,
                telefone = :telefone,
                cro = :cro,
                especialidade = :especialidade
                WHERE id = :id";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':nome' => $data['nome'],
                ':email' => $data['email'] ?: null,
                ':telefone' => $data['telefone'] ?: null,
                ':cro' => $data['cro'] ?: null,
                ':especialidade' => $data['especialidade'] ?: null,
                ':id' => $id,
            ]);
            return [true, $stmt->rowCount()];
        } catch (PDOException $e) {
            return [false, $this->friendlyError($e)];
        }
    }

    /** Retorna [ok, rows|errorMessage] */
    public function delete(int $id): array
    {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM dentistas WHERE id = :id");
            $stmt->execute([':id' => $id]);
            return [true, $stmt->rowCount()];
        } catch (PDOException $e) {
            // Poderá falhar no futuro se tiver FKs (consultas). Tratar mensagem amigável.
            return [false, $this->friendlyError($e)];
        }
    }

    private function friendlyError(PDOException $e): string
    {
        $msg = $e->getMessage();
        if (str_contains($msg, 'uk_dentistas_email')) {
            return 'E-mail já cadastrado para outro dentista.';
        }
        if (str_contains($msg, 'uk_dentistas_cro')) {
            return 'CRO já cadastrado para outro dentista.';
        }
        if (str_contains($msg, 'a foreign key constraint fails')) {
            return 'Não é possível excluir: dentista possui consultas vinculadas.';
        }
        return 'Erro no banco de dados.';
    }
}
