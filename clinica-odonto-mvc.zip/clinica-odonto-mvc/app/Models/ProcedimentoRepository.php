<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\DB;
use PDO;
use PDOException;

final class ProcedimentoRepository
{
    private PDO $pdo;
    public function __construct()
    {
        $this->pdo = DB::conn();
    }

    /** Lista paginada com busca e ordenação. Retorna [items, total]. */
    public function paginate(
        ?string $q,
        string $sort,
        string $dir,
        int $page,
        int $perPage = 10
    ): array {
        $allowedSort = ['nome','preco','duracao_min','created_at'];
        if (!in_array($sort, $allowedSort, true)) $sort = 'created_at';
        $dir = (strtolower($dir) === 'asc') ? 'ASC' : 'DESC';

        $where = '';
        $params = [];
        if ($q !== null && $q !== '') {
            $where = "WHERE (nome LIKE :q OR descricao LIKE :q)";
            $params[':q'] = '%'.$q.'%';
        }

        $offset = max(0, ($page - 1) * $perPage);

        $sqlCount = "SELECT COUNT(*) FROM procedimentos $where";
        $stmt = $this->pdo->prepare($sqlCount);
        $stmt->execute($params);
        $total = (int)$stmt->fetchColumn();

        $sql = "SELECT id, nome, descricao, preco, duracao_min, created_at
                FROM procedimentos
                $where
                ORDER BY $sort $dir
                LIMIT :limit OFFSET :offset";
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $k => $v) { $stmt->bindValue($k, $v); }
        $stmt->bindValue(':limit',  $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset,  PDO::PARAM_INT);
        $stmt->execute();
        $items = $stmt->fetchAll();

        return [$items, $total];
    }

    public function find(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM procedimentos WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Retorna [ok, id|errorMessage] */
    public function insert(array $data): array
    {
        try {
            $sql = "INSERT INTO procedimentos (nome, descricao, preco, duracao_min)
                    VALUES (:nome, :descricao, :preco, :duracao_min)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':nome'        => $data['nome'],
                ':descricao'   => $data['descricao'] ?: null,
                ':preco'       => $data['preco'],
                ':duracao_min' => $data['duracao_min'] !== '' ? (int)$data['duracao_min'] : null,
            ]);
            return [true, (int)$this->pdo->lastInsertId()];
        } catch (PDOException $e) {
            return [false, $this->friendlyError($e)];
        }
    }

    /** Retorna [ok, rows|errorMessage] */
    public function update(int $id, array $data): array
    {
        try {
            $sql = "UPDATE procedimentos SET
                nome = :nome,
                descricao = :descricao,
                preco = :preco,
                duracao_min = :duracao_min
                WHERE id = :id";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([
                ':nome'        => $data['nome'],
                ':descricao'   => $data['descricao'] ?: null,
                ':preco'       => $data['preco'],
                ':duracao_min' => $data['duracao_min'] !== '' ? (int)$data['duracao_min'] : null,
                ':id'          => $id,
            ]);
            return [true, $stmt->rowCount()];
        } catch (PDOException $e) {
            return [false, $this->friendlyError($e)];
        }
    }

    /** Retorna [ok, rows|errorMessage] */
    public function delete(int $id): array
    {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM procedimentos WHERE id = :id");
            $stmt->execute([':id' => $id]);
            return [true, $stmt->rowCount()];
        } catch (PDOException $e) {
            // Pode falhar se houver FKs em consultas (no futuro)
            return [false, $this->friendlyError($e)];
        }
    }

    private function friendlyError(PDOException $e): string
    {
        $msg = $e->getMessage();
        if (str_contains($msg, 'uk_procedimentos_nome')) {
            return 'Nome de procedimento já cadastrado.';
        }
        if (str_contains($msg, 'a foreign key constraint fails')) {
            return 'Não é possível excluir: procedimento está vinculado a consultas.';
        }
        return 'Erro no banco de dados.';
    }
}
