<?php
declare(strict_types=1);

namespace App\Core;

final class Csv
{
    /**
     * Envia um CSV para o navegador com BOM UTF-8 e separador ;
     * $headers: nomes das colunas
     * $rows: array de arrays associativos ou numéricos
     */
    public static function download(string $filename, array $headers, iterable $rows): void
    {
        // Cabeçalhos HTTP
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $out = fopen('php://output', 'w');

        // BOM para Excel no Windows
        echo "\xEF\xBB\xBF";

        // Escreve cabeçalhos
        fputcsv($out, $headers, ';');

        // Escreve linhas
        foreach ($rows as $r) {
            // Garante ordem igual aos headers, se forem associativos
            if (is_array($r) && array_keys($r) !== range(0, count($r) - 1)) {
                $line = [];
                foreach ($headers as $h) {
                    $key = self::keyFromHeader($h);
                    $line[] = $r[$key] ?? '';
                }
                fputcsv($out, $line, ';');
            } else {
                fputcsv($out, (array)$r, ';');
            }
        }

        fclose($out);
        exit;
    }

    /** Converte "Criado em" -> "created_at" (convenção simples). */
    private static function keyFromHeader(string $header): string
    {
        $k = mb_strtolower($header, 'UTF-8');
        $k = str_replace([' ', 'ã', 'ç', 'é', 'í', 'ó', 'ú', 'á', 'ê', 'ô', 'Ã', 'Ç', 'É', 'Í', 'Ó', 'Ú', 'Á', 'Ê', 'Ô'],
                         ['_', 'a', 'c', 'e', 'i', 'o', 'u', 'a', 'e', 'o', 'a', 'c', 'e', 'i', 'o', 'u', 'a', 'e', 'o'], $k);
        return $k;
    }
}
