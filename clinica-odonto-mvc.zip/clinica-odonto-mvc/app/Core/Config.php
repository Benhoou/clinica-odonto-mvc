<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Leitor simples de .env e acesso a configurações.
 * Formato .env: CHAVE=valor (sem aspas). Linhas em branco e começando com # são ignoradas.
 */
final class Config
{
    private static array $env = [];

    public static function loadEnv(string $envPath): void
    {
        self::$env = [];
        if (!is_file($envPath)) {
            // Não falhar — deixamos valores default/ini/getenv
            return;
        }

        $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) continue;
            $parts = explode('=', $line, 2);
            if (count($parts) === 2) {
                [$k, $v] = $parts;
                $k = trim($k);
                $v = trim($v);
                // Remove aspas simples/duplas se houver
                if ((str_starts_with($v, '"') && str_ends_with($v, '"')) ||
                    (str_starts_with($v, "'") && str_ends_with($v, "'"))) {
                    $v = substr($v, 1, -1);
                }
                self::$env[$k] = $v;
                // Também expõe via putenv para libs nativas se necessário
                @putenv("$k=$v");
            }
        }
    }

    public static function get(string $key, ?string $default = null): ?string
    {
        if (array_key_exists($key, self::$env)) return self::$env[$key];
        $val = getenv($key);
        if ($val !== false) return $val;
        return $default;
    }
}
