<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Autoloader simples para o namespace "App\"
 * Converte "App\X\Y" em "app/X/Y.php"
 */
final class Autoloader
{
    private string $baseDir;

    public function __construct(string $baseDir)
    {
        $this->baseDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    }

    public function register(): void
    {
        spl_autoload_register([$this, 'autoload'], true, true);
    }

    private function autoload(string $class): void
    {
        $prefix = 'App\\';
        $len = strlen($prefix);

        // Só lida com classes do nosso namespace
        if (strncmp($class, $prefix, $len) !== 0) {
            return;
        }

        $relative = substr($class, $len);
        $file = $this->baseDir . str_replace('\\', DIRECTORY_SEPARATOR, $relative) . '.php';

        if (is_file($file)) {
            require $file;
        }
    }
}
