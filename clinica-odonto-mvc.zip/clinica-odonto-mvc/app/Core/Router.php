<?php
declare(strict_types=1);

namespace App\Core;

final class Router
{
    private array $routes = ['GET'=>[], 'POST'=>[]];
    private string $basePath = '';
    private array $protectedPrefixes = [];

    public function setBasePath(string $base): void { $this->basePath = $base; }
    public function protectPrefixes(array $prefixes): void { $this->protectedPrefixes = $prefixes; }

    public function get(string $path, callable|array $handler): void  { $this->routes['GET'][$path]  = $handler; }
    public function post(string $path, callable|array $handler): void { $this->routes['POST'][$path] = $handler; }

    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $uri    = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $path   = (string)substr($uri, strlen($this->basePath));
        if ($path === '' || $path[0] !== '/') $path = '/' . $path;

        // proteção /admin/*
        foreach ($this->protectedPrefixes as $prefix) {
            if (str_starts_with($path, $prefix)) {
                if (empty($_SESSION['user'])) {
                    header('Location: ' . (BASE_URL ?: '') . '/login');
                    return;
                }
            }
        }

        $handler = $this->routes[$method][$path] ?? null;
        if (!$handler) {
            http_response_code(404);
            echo "<h1>404 - Rota não encontrada</h1>";
            return;
        }

        $request = new Request();

        if (is_array($handler) && count($handler) === 2) {
            [$class, $methodName] = $handler;
            $controller = new $class();
            echo (string)$controller->$methodName($request);
            return;
        }

        echo (string)call_user_func($handler, $request);
    }
}

final class Request
{
    public array $get;
    public array $post;
    public array $query;

    public function __construct()
    {
        $this->get   = $_GET;
        $this->post  = $_POST;
        $this->query = $_GET;
    }
}
