<?php
declare(strict_types=1);

namespace App\Core;

final class Validation
{
    // ... (mantém validatePaciente, validateDentista, validateProcedimento e isValidDate já enviados)

    /** Validação para CONSULTA */
    public static function validateConsulta(array $data): array
    {
        $errors = [];

        // IDs obrigatórios e inteiros positivos
        foreach (['paciente_id'=>'Paciente','dentista_id'=>'Dentista','procedimento_id'=>'Procedimento'] as $k => $label) {
            $v = (string)($data[$k] ?? '');
            if ($v === '' || !preg_match('/^[1-9]\d*$/', $v)) {
                $errors[$k] = "$label é obrigatório.";
            }
        }

        // data_hora obrigatório: YYYY-MM-DD HH:MM (24h)
        $dt = trim((string)($data['data_hora'] ?? ''));
        if ($dt === '') {
            $errors['data_hora'] = 'Data e hora são obrigatórias.';
        } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}$/', $dt)) {
            $errors['data_hora'] = 'Formato inválido. Use YYYY-MM-DD HH:MM.';
        } else {
            // valida data e hora separadamente
            [$d, $t] = explode(' ', $dt);
            [$y,$m,$day] = array_map('intval', explode('-', $d));
            [$H,$i] = array_map('intval', explode(':', $t));
            if (!checkdate($m, $day, $y) || $H<0 || $H>23 || $i<0 || $i>59) {
                $errors['data_hora'] = 'Data/hora inválidas.';
            }
        }

        // status enum
        $status = (string)($data['status'] ?? 'agendada');
        $allowed = ['agendada','confirmada','realizada','cancelada'];
        if (!in_array($status, $allowed, true)) {
            $errors['status'] = 'Status inválido.';
        }

        // valor_cobrado opcional >= 0
        $valor = trim((string)($data['valor_cobrado'] ?? ''));
        if ($valor !== '') {
            if (!preg_match('/^\d+(\.\d{1,2})?$/', $valor)) {
                $errors['valor_cobrado'] = 'Valor inválido. Use até 2 casas decimais, ex.: 100.00';
            } elseif ((float)$valor < 0) {
                $errors['valor_cobrado'] = 'Valor não pode ser negativo.';
            }
        }

        return [empty($errors), $errors];
    }
}
