<?php
declare(strict_types=1);

namespace App\Core;

final class Auth
{
    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function check(): bool
    {
        return isset($_SESSION['user']) && is_array($_SESSION['user']);
    }

    public static function requireLogin(string $redirectBase): void
    {
        if (!self::check()) {
            Flash::error('Você precisa estar logado para acessar.');
            header('Location: ' . $redirectBase . '/login');
            exit;
        }
    }

    public static function logout(): void
    {
        unset($_SESSION['user']);
        session_regenerate_id(true);
        Csrf::regenerate();
    }
}
