<?php
declare(strict_types=1);

namespace App\Core;

final class Request
{
    public function method(): string
    {
        return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    }

    public function isGet(): bool
    {
        return $this->method() === 'GET';
    }

    public function isPost(): bool
    {
        return $this->method() === 'POST';
    }

    public function uri(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $qpos = strpos($uri, '?');
        if ($qpos !== false) {
            $uri = substr($uri, 0, $qpos);
        }
        return rtrim($uri, '/') ?: '/';
    }

    /**
     * Lê um parâmetro de query string (GET) com fallback seguro.
     */
    public function get(string $key, $default = null)
    {
        // Tenta filter_input primeiro (seguro); se vier null, usa superglobal
        $val = filter_input(INPUT_GET, $key, FILTER_UNSAFE_RAW, FILTER_NULL_ON_FAILURE);
        if ($val === null) {
            $val = $_GET[$key] ?? $default;
        }
        return is_string($val) ? trim($val) : ($val ?? $default);
    }

    /**
     * Lê um parâmetro do corpo (POST) com fallback seguro.
     */
    public function post(string $key, $default = null)
    {
        $val = filter_input(INPUT_POST, $key, FILTER_UNSAFE_RAW, FILTER_NULL_ON_FAILURE);
        if ($val === null) {
            $val = $_POST[$key] ?? $default;
        }
        return is_string($val) ? trim($val) : ($val ?? $default);
    }

    /**
     * Lê de POST se for POST; senão tenta GET (útil para formulários/filters).
     */
    public function input(string $key, $default = null)
    {
        if ($this->isPost()) {
            $v = $this->post($key, $default);
            if ($v !== null && $v !== '') return $v;
        }
        return $this->get($key, $default);
    }

    /** Todos os parâmetros de query */
    public function queryParams(): array
    {
        return $_GET ?? [];
    }

    /** Todos os parâmetros do corpo */
    public function bodyParams(): array
    {
        return $_POST ?? [];
    }

    /** Todos os parâmetros conforme método */
    public function all(): array
    {
        return $this->isPost() ? $this->bodyParams() : $this->queryParams();
    }

    /** Arquivos enviados (equivalente a $_FILES) */
    public function files(): array
    {
        return $_FILES ?? [];
    }
}
