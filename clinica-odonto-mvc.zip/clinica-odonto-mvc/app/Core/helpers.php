<?php
declare(strict_types=1);

/** Escape HTML */
if (!function_exists('e')) {
    function e(mixed $v): string {
        return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    }
}

/** URL para assets */
if (!function_exists('asset')) {
    function asset(string $path): string {
        return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
    }
}

/** Alias simples */
if (!function_exists('url')) {
    function url(string $path): string {
        return asset($path);
    }
}

/**
 * Renderiza a view dentro do layout
 * - $view relativo a app/Views, sem .php (ex.: "auth/login")
 * - $data vira variáveis da view
 */
if (!function_exists('view')) {
    function view(string $view, array $data = []): void {
        $file = APP_PATH . '/Views/' . ltrim($view, '/') . '.php';
        if (!is_file($file)) {
            throw new \RuntimeException("View não encontrada: {$view}");
        }
        extract($data, EXTR_SKIP);
        $base     = BASE_URL;
        $viewFile = $file; // o layout inclui este arquivo

        require APP_PATH . '/Views/layout.php';
    }
}
