<?php
declare(strict_types=1);

/** Token CSRF em sessão */
if (!function_exists('csrf_token')) {
    function csrf_token(): string {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return (string)$_SESSION['csrf_token'];
    }
}

/** Campo hidden para formularios */
if (!function_exists('csrf_field')) {
    function csrf_field(): string {
        return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
    }
}

/** Valida POST com token */
if (!function_exists('csrf_check')) {
    function csrf_check(): bool {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') return true;
        $sent = (string)($_POST['_token'] ?? '');
        $sess = (string)($_SESSION['csrf_token'] ?? '');
        return $sent !== '' && $sess !== '' && hash_equals($sess, $sent);
    }
}
