<?php
/** @var string $q */
/** @var int $page */
/** @var string $sort */
/** @var string $dir */
/** @var array $items */
/** @var int $total */
/** @var int $totalPages */

$q          = isset($q)    ? (string)$q    : '';
$page       = isset($page) ? (int)$page    : 1;
$sort       = isset($sort) ? (string)$sort : 'data_hora';
$dir        = isset($dir)  ? (string)$dir  : 'asc';
$items      = isset($items) && is_array($items) ? $items : [];
$total      = isset($total) ? (int)$total : 0;
$totalPages = isset($totalPages) ? (int)$totalPages : 1;

$base = BASE_URL ?: '';

$qsBase = function(array $extra = []) use ($q, $page, $sort, $dir): string {
    $params = ['q'=>$q,'page'=>$page,'sort'=>$sort,'dir'=>$dir] + $extra;
    $params = array_filter($params, fn($v)=>$v!==null && $v!=='');
    return '?' . http_build_query($params);
};
$toggleDir = function(string $col) use ($sort, $dir): string {
    return ($sort === $col && strtolower($dir)==='asc') ? 'desc' : 'asc';
};

/* helpers locais para formatar com segurança */
$fmtDate = function($v): string {
    if (!$v) return '';
    $ts = strtotime((string)$v);
    return $ts ? date('Y-m-d H:i', $ts) : '';
};
$fmtMoney = function($v): string {
    return is_numeric($v) ? number_format((float)$v, 2, ',', '.') : '';
};

$msg = $_GET['msg'] ?? '';
$err = $_GET['err'] ?? '';
?>
<section class="card">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
    <h1>Consultas</h1>
    <a class="btn" href="<?= e($base . '/consultas/create') ?>">+ Nova</a>
  </div>

  <?php if ($msg): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="alert danger"><?= e($err) ?></div><?php endif; ?>

  <form method="get" action="<?= e($base . '/consultas') ?>" class="form-inline" style="margin:8px 0">
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="Buscar por paciente, dentista, procedimento ou status">
    <button type="submit">Buscar</button>
    <?php if ($q!==''): ?>
      <a href="<?= e($base . '/consultas') ?>" class="link">Limpar</a>
    <?php endif; ?>
  </form>

  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th><a href="<?= e($base . '/consultas' . $qsBase(['sort'=>'data_hora',   'dir'=>$toggleDir('data_hora'),   'page'=>1])) ?>">Data/Hora</a></th>
          <th><a href="<?= e($base . '/consultas' . $qsBase(['sort'=>'paciente',    'dir'=>$toggleDir('paciente'),    'page'=>1])) ?>">Paciente</a></th>
          <th><a href="<?= e($base . '/consultas' . $qsBase(['sort'=>'dentista',    'dir'=>$toggleDir('dentista'),    'page'=>1])) ?>">Dentista</a></th>
          <th><a href="<?= e($base . '/consultas' . $qsBase(['sort'=>'procedimento','dir'=>$toggleDir('procedimento'),'page'=>1])) ?>">Procedimento</a></th>
          <th><a href="<?= e($base . '/consultas' . $qsBase(['sort'=>'status',      'dir'=>$toggleDir('status'),      'page'=>1])) ?>">Status</a></th>
          <th>Valor</th>
          <th style="width:160px">Ações</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$items): ?>
        <tr><td colspan="7">Nenhum registro encontrado.</td></tr>
      <?php else: foreach ($items as $row): ?>
        <tr>
          <td><?= e($fmtDate($row['data_hora'] ?? null)) ?></td>
          <td><?= e($row['paciente']     ?? '') ?></td>
          <td><?= e($row['dentista']     ?? '') ?></td>
          <td><?= e($row['procedimento'] ?? '') ?></td>
          <td><?= e($row['status']       ?? '') ?></td>
          <td><?= e($fmtMoney($row['valor_cobrado'] ?? null)) ?></td>
          <td class="actions">
            <a class="btn-sm" href="<?= e($base . '/consultas/edit?id='.(int)($row['id'] ?? 0)) ?>">Editar</a>
            <form method="post" action="<?= e($base . '/consultas/delete') ?>" onsubmit="return confirm('Excluir esta consulta?');" style="display:inline">
              <input type="hidden" name="id" value="<?= e((string)($row['id'] ?? '')) ?>">
              <!-- CSRF -->
              <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
              <button type="submit" class="btn-sm danger">Excluir</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($totalPages > 1): ?>
    <nav class="pagination">
      <?php for ($p = 1; $p <= $totalPages; $p++): ?>
        <?php if ($p == $page): ?>
          <span class="page current"><?= $p ?></span>
        <?php else: ?>
          <a class="page" href="<?= e($base . '/consultas' . $qsBase(['page'=>$p])) ?>"><?= $p ?></a>
        <?php endif; ?>
      <?php endfor; ?>
    </nav>
  <?php endif; ?>

  <p style="margin-top:8px"><small>Total: <?= (int)$total ?> registro(s)</small></p>
</section>
