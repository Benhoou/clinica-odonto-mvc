<?php
$base = BASE_URL ?: '';
$isEdit = isset($paciente['id']) && $paciente['id'];
$title ??= ($isEdit ? 'Editar Paciente' : 'Novo Paciente');
?>
<section class="card">
  <h1><?= e($title) ?></h1>

  <form method="post" action="<?= e($base . ($isEdit ? '/pacientes/update' : '/pacientes/store')) ?>">
    <?= csrf_field() ?>
    <?php if ($isEdit): ?>
      <input type="hidden" name="id" value="<?= e((string)$paciente['id']) ?>">
    <?php endif; ?>

    <div>
      <label>Nome *</label>
      <input type="text" name="nome" required value="<?= e($paciente['nome'] ?? '') ?>">
    </div>

    <div>
      <label>E-mail</label>
      <input type="email" name="email" value="<?= e($paciente['email'] ?? '') ?>">
    </div>

    <div>
      <label>Telefone</label>
      <input type="text" name="telefone" value="<?= e($paciente['telefone'] ?? '') ?>">
    </div>

    <div>
      <label>Data de nascimento</label>
      <input type="date" name="data_nascimento" value="<?= e($paciente['data_nascimento'] ?? '') ?>">
    </div>

    <div>
      <label>CPF</label>
      <input type="text" name="cpf" value="<?= e($paciente['cpf'] ?? '') ?>">
    </div>

    <div>
      <label>Endereço</label>
      <input type="text" name="endereco" value="<?= e($paciente['endereco'] ?? '') ?>">
    </div>

    <div>
      <label>Observações</label>
      <textarea name="observacoes" rows="3"><?= e($paciente['observacoes'] ?? '') ?></textarea>
    </div>

    <div style="margin-top:10px">
      <button type="submit"><?= $isEdit ? 'Salvar alterações' : 'Cadastrar' ?></button>
      <a class="link" href="<?= e($base.'/pacientes') ?>">Voltar</a>
    </div>
  </form>
</section>
