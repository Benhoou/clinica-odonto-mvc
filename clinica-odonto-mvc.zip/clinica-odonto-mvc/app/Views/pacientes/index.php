<?php
$base = BASE_URL ?: '';

$qsBase = function(array $extra = []) use ($q, $page, $sort, $dir): string {
    $params = ['q' => $q, 'page' => $page, 'sort' => $sort, 'dir' => $dir] + $extra;
    $params = array_filter($params, fn($v) => $v !== null && $v !== '');
    return '?' . http_build_query($params);
};

$toggleDir = function(string $col) use ($sort, $dir): string {
    return ($sort === $col && strtolower((string)$dir) === 'asc') ? 'desc' : 'asc';
};
?>
<section class="card">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
    <h1>Pacientes</h1>
    <div>
      <a class="btn" href="<?= e($base . '/pacientes/create') ?>">+ Novo</a>
      <a class="btn" href="<?= e($base . '/pacientes/export' . $qsBase(['page' => null])) ?>">Exportar CSV</a>
    </div>
  </div>

  <form method="get" action="<?= e($base . '/pacientes') ?>" class="form-inline" style="margin:8px 0;">
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="Buscar por nome, email, telefone, CPF" style="min-width:320px;">
    <button type="submit">Buscar</button>
    <?php if ($q !== ''): ?>
      <a href="<?= e($base . '/pacientes') ?>" class="link" style="margin-left:8px">Limpar</a>
    <?php endif; ?>
  </form>

  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th><a href="<?= e($base . '/pacientes' . $qsBase(['sort'=>'nome', 'dir'=>$toggleDir('nome'), 'page'=>1])) ?>">Nome</a></th>
          <th><a href="<?= e($base . '/pacientes' . $qsBase(['sort'=>'email', 'dir'=>$toggleDir('email'), 'page'=>1])) ?>">E-mail</a></th>
          <th><a href="<?= e($base . '/pacientes' . $qsBase(['sort'=>'telefone', 'dir'=>$toggleDir('telefone'), 'page'=>1])) ?>">Telefone</a></th>
          <th><a href="<?= e($base . '/pacientes' . $qsBase(['sort'=>'data_nascimento', 'dir'=>$toggleDir('data_nascimento'), 'page'=>1])) ?>">Nascimento</a></th>
          <th><a href="<?= e($base . '/pacientes' . $qsBase(['sort'=>'created_at', 'dir'=>$toggleDir('created_at'), 'page'=>1])) ?>">Criado em</a></th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($items)): ?>
          <tr><td colspan="6">Nenhum registro encontrado.</td></tr>
        <?php else: ?>
          <?php foreach ($items as $row): ?>
            <tr>
              <td><?= e($row['nome'] ?? '') ?></td>
              <td><?= e($row['email'] ?? '') ?></td>
              <td><?= e($row['telefone'] ?? '') ?></td>
              <td><?= e($row['data_nascimento'] ?? '') ?></td>
              <td><?= e($row['created_at'] ?? '') ?></td>
              <td style="white-space:nowrap">
                <a class="btn-sm" href="<?= e($base . '/pacientes/edit?id=' . (int)$row['id']) ?>">Editar</a>
                <form method="post" action="<?= e($base . '/pacientes/delete') ?>" style="display:inline" onsubmit="return confirm('Excluir este paciente?');">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= e((string)$row['id']) ?>">
                  <button type="submit" class="btn-sm danger">Excluir</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <?php if ($totalPages > 1): ?>
    <nav class="pagination" style="margin-top:8px; display:flex; gap:6px; flex-wrap:wrap;">
      <?php for ($p = 1; $p <= $totalPages; $p++): ?>
        <?php if ($p == $page): ?>
          <span class="page current"><?= $p ?></span>
        <?php else: ?>
          <a class="page" href="<?= e($base . '/pacientes' . $qsBase(['page'=>$p])) ?>"><?= $p ?></a>
        <?php endif; ?>
      <?php endfor; ?>
    </nav>
    <div style="margin-top:6px;color:#555;"><?= (int)$total ?> registro(s)</div>
  <?php else: ?>
    <div style="margin-top:6px;color:#555;"><?= (int)$total ?> registro(s)</div>
  <?php endif; ?>
</section>
