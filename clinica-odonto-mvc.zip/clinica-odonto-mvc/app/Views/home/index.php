<?php
/** @var array $stats */
/** @var array $proximas */
/** @var int   $pendentes */
$base = BASE_URL ?: '';
?>
<section class="card">
  <h1>Bem-vindo 👋</h1>

  <?php if ($pendentes > 0): ?>
    <div class="alert" style="background:#fff3cd;border:1px solid #ffe69c;color:#7a5d00;padding:10px;border-radius:8px;margin:12px 0;">
      Existem <strong><?= (int)$pendentes ?></strong> consultas com status <em>pendente</em>.
      <a href="<?= e($base.'/consultas?q=pendente') ?>" class="link">Ver agora</a>
    </div>
  <?php endif; ?>

  <!-- Cards de contagem -->
  <div style="display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:12px;margin:12px 0;">
    <div class="card" style="padding:14px;">
      <div style="font-size:13px;color:#666;">Pacientes</div>
      <div style="font-size:28px;font-weight:700;"><?= (int)$stats['pacientes'] ?></div>
      <a href="<?= e($base.'/pacientes') ?>" class="link">Abrir lista</a>
    </div>
    <div class="card" style="padding:14px;">
      <div style="font-size:13px;color:#666;">Dentistas</div>
      <div style="font-size:28px;font-weight:700;"><?= (int)$stats['dentistas'] ?></div>
      <a href="<?= e($base.'/dentistas') ?>" class="link">Abrir lista</a>
    </div>
    <div class="card" style="padding:14px;">
      <div style="font-size:13px;color:#666;">Procedimentos</div>
      <div style="font-size:28px;font-weight:700;"><?= (int)$stats['procedimentos'] ?></div>
      <a href="<?= e($base.'/procedimentos') ?>" class="link">Abrir lista</a>
    </div>
    <div class="card" style="padding:14px;">
      <div style="font-size:13px;color:#666;">Consultas hoje</div>
      <div style="font-size:28px;font-weight:700;"><?= (int)$stats['hoje'] ?></div>
      <a href="<?= e($base.'/consultas?q=hoje') ?>" class="link">Ver agenda</a>
    </div>
  </div>

  <!-- Próximas consultas -->
  <h2 style="margin-top:18px;">Próximas consultas</h2>
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th>Data/Hora</th>
          <th>Paciente</th>
          <th>Dentista</th>
          <th>Procedimento</th>
          <th>Status</th>
          <th style="width:120px">Ações</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$proximas): ?>
          <tr><td colspan="6">Nada por aqui. 👌</td></tr>
        <?php else: foreach($proximas as $row): ?>
          <tr>
            <td><?= e(date('d/m/Y H:i', strtotime($row['data_hora']))) ?></td>
            <td><?= e($row['paciente']) ?></td>
            <td><?= e($row['dentista']) ?></td>
            <td><?= e($row['procedimento']) ?></td>
            <td>
              <?php
                $s = strtolower((string)$row['status']);
                $bg = [
                  'pendente'   => '#fff3cd',
                  'confirmada' => '#d1e7dd',
                  'cancelada'  => '#f8d7da',
                ][$s] ?? '#e9ecef';
                $fg = [
                  'pendente'   => '#7a5d00',
                  'confirmada' => '#0f5132',
                  'cancelada'  => '#842029',
                ][$s] ?? '#495057';
              ?>
              <span style="padding:2px 8px;border-radius:999px;background:<?= $bg ?>;color:<?= $fg ?>;font-size:12px;">
                <?= e(ucfirst($s)) ?>
              </span>
            </td>
            <td class="actions">
              <a class="btn-sm" href="<?= e($base.'/consultas/edit?id='.(int)$row['id']) ?>">Editar</a>
              <form method="post" action="<?= e($base.'/consultas/delete') ?>" style="display:inline" onsubmit="return confirm('Excluir esta consulta?');">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= e((string)$row['id']) ?>">
                <button type="submit" class="btn-sm danger">Excluir</button>
              </form>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Atalhos rápidos -->
  <h2 style="margin-top:18px;">Atalhos rápidos</h2>
  <div style="display:flex;flex-wrap:wrap;gap:8px;">
    <a class="btn" href="<?= e($base.'/pacientes/create') ?>">+ Paciente</a>
    <a class="btn" href="<?= e($base.'/consultas/create') ?>">+ Consulta</a>
    <a class="btn" href="<?= e($base.'/procedimentos/create') ?>">+ Procedimento</a>
    <a class="btn" href="<?= e($base.'/dentistas/create') ?>">+ Dentista</a>
  </div>
</section>
