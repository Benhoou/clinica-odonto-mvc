<?php
/**
 * Espera: $title, $dentista, $errors, $isEdit
 * Estes fallbacks evitam warnings se algo vier ausente.
 */
$base     = BASE_URL ?: '';
$dentista = $dentista ?? [
    'id'            => null,
    'nome'          => '',
    'email'         => '',
    'telefone'      => '',
    'cro'           => '',
    'especialidade' => '',
];
$errors   = $errors ?? [];
$isEdit   = isset($isEdit) ? (bool)$isEdit : (!empty($dentista['id']));
?>
<section class="card">
  <h1><?= e($title ?? 'Dentista') ?></h1>

  <?php if (!empty($errors['_global'])): ?>
    <div class="alert danger"><?= e($errors['_global']) ?></div>
  <?php endif; ?>

  <form method="post" action="<?= e($base . ($isEdit ? '/dentistas/update' : '/dentistas/store')) ?>">
    <?php
      // Use SEMPRE o helper — ele existe no helpers.php e evita problema de autoload/namespacing:
      if (function_exists('csrf_field')) {
          echo csrf_field();
      } else {
          // fallback extremo: sem token (evite em produção)
          echo '<input type="hidden" name="_csrf" value="">';
      }
    ?>

    <?php if ($isEdit): ?>
      <input type="hidden" name="id" value="<?= e((string)$dentista['id']) ?>">
    <?php endif; ?>

    <div class="grid-2">
      <div>
        <label>Nome *</label>
        <input type="text" name="nome" value="<?= e((string)$dentista['nome']) ?>" required>
        <?php if (!empty($errors['nome'])): ?><div class="error"><?= e($errors['nome']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>E-mail</label>
        <input type="email" name="email" value="<?= e((string)$dentista['email']) ?>">
        <?php if (!empty($errors['email'])): ?><div class="error"><?= e($errors['email']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Telefone</label>
        <input type="text" name="telefone" value="<?= e((string)$dentista['telefone']) ?>">
        <?php if (!empty($errors['telefone'])): ?><div class="error"><?= e($errors['telefone']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>CRO</label>
        <input type="text" name="cro" value="<?= e((string)$dentista['cro']) ?>">
        <?php if (!empty($errors['cro'])): ?><div class="error"><?= e($errors['cro']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Especialidade</label>
        <input type="text" name="especialidade" value="<?= e((string)$dentista['especialidade']) ?>">
        <?php if (!empty($errors['especialidade'])): ?><div class="error"><?= e($errors['especialidade']) ?></div><?php endif; ?>
      </div>
    </div>

    <div style="margin-top:12px; display:flex; gap:8px;">
      <button type="submit"><?= $isEdit ? 'Salvar alterações' : 'Cadastrar' ?></button>
      <a class="btn" href="<?= e($base . '/dentistas') ?>">Voltar</a>
    </div>
  </form>
</section>
