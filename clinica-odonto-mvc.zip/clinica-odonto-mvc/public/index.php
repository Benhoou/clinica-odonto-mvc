<?php
declare(strict_types=1);

session_start();
ini_set('display_errors', '1');
error_reporting(E_ALL);

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . DIRECTORY_SEPARATOR . 'app');

// Autoloader e helpers
require APP_PATH . '/Core/Autoloader.php';
$loader = new App\Core\Autoloader(APP_PATH);
$loader->register();

require_once APP_PATH . '/Core/helpers.php'; // e(), asset(), view(), etc.
require_once APP_PATH . '/Core/Csrf.php';    // csrf_token(), csrf_field(), csrf_check()
require_once APP_PATH . '/Core/Flash.php';   // Flash::set/get/pull/clear()

// BASE_URL calculado a partir do script atual
$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
$scriptDir  = str_replace('\\', '/', dirname($scriptName));
$scriptDir  = ($scriptDir === '/' ? '' : $scriptDir);
$baseUrl    = rawurldecode(rtrim($scriptDir, '/'));
define('BASE_URL', $baseUrl);

use App\Core\Config;
use App\Core\Router;

// Carrega .env (se existir)
if (class_exists(Config::class)) {
    Config::loadEnv(BASE_PATH . '/.env');
}

// Router
$router = new Router();
$router->setBasePath(BASE_URL);

/** Rotas públicas */
$router->get('/',      [App\Controllers\HomeController::class, 'index']);
$router->get('/hello', [App\Controllers\HelloController::class, 'message']);

/** Login/Logout */
$router->get('/login',  [App\Controllers\AuthController::class, 'showLogin']);
$router->post('/login', [App\Controllers\AuthController::class, 'login']);
$router->post('/logout',[App\Controllers\AuthController::class, 'logout']);

/** Pacientes */
$router->get('/pacientes',         [App\Controllers\PacientesController::class, 'index']);
$router->get('/pacientes/create',  [App\Controllers\PacientesController::class, 'create']);
$router->post('/pacientes/store',  [App\Controllers\PacientesController::class, 'store']);
$router->get('/pacientes/edit',    [App\Controllers\PacientesController::class, 'edit']);
$router->post('/pacientes/update', [App\Controllers\PacientesController::class, 'update']);
$router->post('/pacientes/delete', [App\Controllers\PacientesController::class, 'delete']);
$router->get('/pacientes/export',  [App\Controllers\PacientesController::class, 'export']);

/** Dentistas */
$router->get('/dentistas',         [App\Controllers\DentistasController::class, 'index']);
$router->get('/dentistas/create',  [App\Controllers\DentistasController::class, 'create']);
$router->post('/dentistas/store',  [App\Controllers\DentistasController::class, 'store']);
$router->get('/dentistas/edit',    [App\Controllers\DentistasController::class, 'edit']);
$router->post('/dentistas/update', [App\Controllers\DentistasController::class, 'update']);
$router->post('/dentistas/delete', [App\Controllers\DentistasController::class, 'delete']);

/** Procedimentos */
$router->get('/procedimentos',         [App\Controllers\ProcedimentosController::class, 'index']);
$router->get('/procedimentos/create',  [App\Controllers\ProcedimentosController::class, 'create']);
$router->post('/procedimentos/store',  [App\Controllers\ProcedimentosController::class, 'store']);
$router->get('/procedimentos/edit',    [App\Controllers\ProcedimentosController::class, 'edit']);
$router->post('/procedimentos/update', [App\Controllers\ProcedimentosController::class, 'update']);
$router->post('/procedimentos/delete', [App\Controllers\ProcedimentosController::class, 'delete']);

/** Consultas */
$router->get('/consultas',         [App\Controllers\ConsultasController::class, 'index']);
$router->get('/consultas/create',  [App\Controllers\ConsultasController::class, 'create']);
$router->post('/consultas/store',  [App\Controllers\ConsultasController::class, 'store']);
$router->get('/consultas/edit',    [App\Controllers\ConsultasController::class, 'edit']);
$router->post('/consultas/update', [App\Controllers\ConsultasController::class, 'update']);
$router->post('/consultas/delete', [App\Controllers\ConsultasController::class, 'delete']);

/** Admin protegido (se quiser usar depois) */
$router->protectPrefixes(['/admin']);

$router->dispatch();
