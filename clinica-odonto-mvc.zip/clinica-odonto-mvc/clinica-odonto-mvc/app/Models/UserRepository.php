<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\DB;
use PDO;

final class UserRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = DB::conn();
    }

    /** Lê na tabela 'usuarios' */
    public function findByEmail(string $email): ?array
    {
        $sql = 'SELECT id, nome, email, senha_hash, role FROM usuarios WHERE email = :email LIMIT 1';
        $st  = $this->pdo->prepare($sql);
        $st->bindValue(':email', $email);
        $st->execute();
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }
}
