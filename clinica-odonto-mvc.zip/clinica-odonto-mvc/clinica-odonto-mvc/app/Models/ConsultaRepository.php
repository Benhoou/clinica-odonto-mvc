<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\DB;

final class ConsultaRepository
{
    /**
     * Lista paginada + total
     */
    public function paginate(?string $q, string $sort, string $dir, int $page, int $perPage = 10): array
    {
        $q   = trim((string)$q);                        // 🔧 normaliza NULL -> ''
        $dir = strtolower($dir) === 'desc' ? 'DESC' : 'ASC';

        // Colunas permitidas para ordenação
        $allowed = [
            'data_hora'    => 'c.data_hora',
            'paciente'     => 'p.nome',
            'dentista'     => 'd.nome',
            'procedimento' => 'pr.nome',
            'status'       => 'c.status',
        ];
        $orderBy = $allowed[$sort] ?? 'c.data_hora';

        $offset = ($page - 1) * $perPage;

        $pdo = DB::conn();

        $sqlBase = "
            FROM consultas c
            JOIN pacientes     p  ON p.id  = c.paciente_id
            JOIN dentistas     d  ON d.id  = c.dentista_id
            JOIN procedimentos pr ON pr.id = c.procedimento_id
            WHERE 1 = 1
        ";

        $params = [];
        if ($q !== '') {
            $sqlBase .= "
              AND (
                   p.nome   LIKE :q
                OR d.nome   LIKE :q
                OR pr.nome  LIKE :q
                OR c.status LIKE :q
              )
            ";
            $params[':q'] = "%{$q}%";
        }

        // total
        $stmt = $pdo->prepare("SELECT COUNT(*) {$sqlBase}");
        $stmt->execute($params);
        $total = (int)$stmt->fetchColumn();

        // página
        $sql = "
            SELECT
              c.id, c.data_hora, c.status, c.valor_cobrado,
              p.nome  AS paciente,
              d.nome  AS dentista,
              pr.nome AS procedimento
            {$sqlBase}
            ORDER BY {$orderBy} {$dir}
            LIMIT :limit OFFSET :offset
        ";
        $stmt = $pdo->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v, \PDO::PARAM_STR);
        }
        $stmt->bindValue(':limit',  $perPage, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset,  \PDO::PARAM_INT);
        $stmt->execute();

        $items = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        return [$items, $total];
    }

    /**
     * Lista completa filtrada (para export)
     */
    public function listFiltered(?string $q, string $sort, string $dir): array
    {
        $q   = trim((string)$q);
        $dir = strtolower($dir) === 'desc' ? 'DESC' : 'ASC';

        $allowed = [
            'data_hora'    => 'c.data_hora',
            'paciente'     => 'p.nome',
            'dentista'     => 'd.nome',
            'procedimento' => 'pr.nome',
            'status'       => 'c.status',
        ];
        $orderBy = $allowed[$sort] ?? 'c.data_hora';

        $pdo = DB::conn();

        $sqlBase = "
            FROM consultas c
            JOIN pacientes     p  ON p.id  = c.paciente_id
            JOIN dentistas     d  ON d.id  = c.dentista_id
            JOIN procedimentos pr ON pr.id = c.procedimento_id
            WHERE 1 = 1
        ";
        $params = [];

        if ($q !== '') {
            $sqlBase .= "
              AND (
                   p.nome   LIKE :q
                OR d.nome   LIKE :q
                OR pr.nome  LIKE :q
                OR c.status LIKE :q
              )
            ";
            $params[':q'] = "%{$q}%";
        }

        $sql = "
            SELECT
              c.id, c.data_hora, c.status, c.valor_cobrado,
              p.nome  AS paciente,
              d.nome  AS dentista,
              pr.nome AS procedimento
            {$sqlBase}
            ORDER BY {$orderBy} {$dir}
        ";

        $stmt = $pdo->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v, \PDO::PARAM_STR);
        }
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /** CRUD básicos (ajuste conforme seus campos/validações) */
    public function find(int $id): ?array
    {
        $pdo = DB::conn();
        $stmt = $pdo->prepare("
            SELECT c.*
            FROM consultas c
            WHERE c.id = :id
            LIMIT 1
        ");
        $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    public function insert(array $data): array
    {
        try {
            $pdo = DB::conn();
            $stmt = $pdo->prepare("
                INSERT INTO consultas
                  (paciente_id, dentista_id, procedimento_id, data_hora, status, observacoes, valor_cobrado)
                VALUES (:paciente_id, :dentista_id, :procedimento_id, :data_hora, :status, :observacoes, :valor_cobrado)
            ");
            $stmt->bindValue(':paciente_id',     (int)$data['paciente_id'],     \PDO::PARAM_INT);
            $stmt->bindValue(':dentista_id',     (int)$data['dentista_id'],     \PDO::PARAM_INT);
            $stmt->bindValue(':procedimento_id', (int)$data['procedimento_id'], \PDO::PARAM_INT);
            $stmt->bindValue(':data_hora',       (string)$data['data_hora']);
            $stmt->bindValue(':status',          (string)$data['status']);
            $stmt->bindValue(':observacoes',     (string)$data['observacoes']);
            if ($data['valor_cobrado'] === null) {
                $stmt->bindValue(':valor_cobrado', null, \PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(':valor_cobrado', (float)$data['valor_cobrado']);
            }
            $stmt->execute();
            return [true, (int)$pdo->lastInsertId()];
        } catch (\Throwable $e) {
            return [false, $e->getMessage()];
        }
    }

    public function update(int $id, array $data): array
    {
        try {
            $pdo = DB::conn();
            $stmt = $pdo->prepare("
                UPDATE consultas
                   SET paciente_id=:paciente_id,
                       dentista_id=:dentista_id,
                       procedimento_id=:procedimento_id,
                       data_hora=:data_hora,
                       status=:status,
                       observacoes=:observacoes,
                       valor_cobrado=:valor_cobrado
                 WHERE id=:id
            ");
            $stmt->bindValue(':id',              $id, \PDO::PARAM_INT);
            $stmt->bindValue(':paciente_id',     (int)$data['paciente_id'],     \PDO::PARAM_INT);
            $stmt->bindValue(':dentista_id',     (int)$data['dentista_id'],     \PDO::PARAM_INT);
            $stmt->bindValue(':procedimento_id', (int)$data['procedimento_id'], \PDO::PARAM_INT);
            $stmt->bindValue(':data_hora',       (string)$data['data_hora']);
            $stmt->bindValue(':status',          (string)$data['status']);
            $stmt->bindValue(':observacoes',     (string)$data['observacoes']);
            if ($data['valor_cobrado'] === null) {
                $stmt->bindValue(':valor_cobrado', null, \PDO::PARAM_NULL);
            } else {
                $stmt->bindValue(':valor_cobrado', (float)$data['valor_cobrado']);
            }
            $stmt->execute();
            return [true, $id];
        } catch (\Throwable $e) {
            return [false, $e->getMessage()];
        }
    }

    public function delete(int $id): array
    {
        try {
            $pdo = DB::conn();
            $stmt = $pdo->prepare("DELETE FROM consultas WHERE id = :id");
            $stmt->bindValue(':id', $id, \PDO::PARAM_INT);
            $stmt->execute();
            return [true, $id];
        } catch (\Throwable $e) {
            return [false, $e->getMessage()];
        }
    }
}
