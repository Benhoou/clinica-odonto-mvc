<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Csrf;
use App\Core\Flash;
use App\Models\ProcedimentoRepository;

final class ProcedimentosController
{
    private ProcedimentoRepository $repo;

    public function __construct()
    {
        $this->repo = new ProcedimentoRepository();
    }

    /** GET /procedimentos */
    public function index(Request $req): string
    {
        $q    = isset($req->query['q']) ? trim((string)$req->query['q']) : '';
        $page = max(1, (int)($req->query['page'] ?? 1));
        $sort = (string)($req->query['sort'] ?? 'created_at');
        $dir  = (string)($req->query['dir']  ?? 'desc');

        [$items, $total] = $this->repo->paginate($q, $sort, $dir, $page, 10);
        $totalPages = max(1, (int)ceil($total / 10));

        view('procedimentos/index', [
            'title'      => 'Procedimentos',
            'base'       => BASE_URL,
            'items'      => $items,
            'total'      => $total,
            'q'          => $q,
            'page'       => $page,
            'sort'       => $sort,
            'dir'        => $dir,
            'totalPages' => $totalPages,
        ]);

        return '';
    }

    /** GET /procedimentos/create */
    public function create(Request $req): string
    {
        $proc = [
            'id'               => null,
            'nome'             => '',
            'preco'            => '',
            'duracao_minutos'  => '',
            'descricao'        => '',
        ];

        view('procedimentos/form', [
            'title'  => 'Novo Procedimento',
            'base'   => BASE_URL,
            'proc'   => $proc,
            'errors' => [],
            'isEdit' => false,
        ]);

        return '';
    }

    /** POST /procedimentos/store */
    public function store(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        $data = [
            'nome'            => trim((string)$req->post['nome'] ?? ''),
            'preco'           => trim((string)$req->post['preco'] ?? ''),
            'duracao_minutos' => trim((string)$req->post['duracao_minutos'] ?? ''),
            'descricao'       => trim((string)$req->post['descricao'] ?? ''),
        ];

        $errors = [];
        if ($data['nome'] === '') {
            $errors['nome'] = 'Nome é obrigatório.';
        }

        if ($data['preco'] !== '' && !is_numeric(str_replace([','], ['.'], $data['preco']))) {
            $errors['preco'] = 'Preço inválido.';
        }

        if ($data['duracao_minutos'] !== '' && !ctype_digit($data['duracao_minutos'])) {
            $errors['duracao_minutos'] = 'Duração deve ser um número inteiro em minutos.';
        }

        if ($errors) {
            view('procedimentos/form', [
                'title'  => 'Novo Procedimento',
                'base'   => BASE_URL,
                'proc'   => $data + ['id' => null],
                'errors' => $errors,
                'isEdit' => false,
            ]);
            return '';
        }

        // Normaliza preço para ponto (opcional)
        if ($data['preco'] !== '') {
            $data['preco'] = str_replace(',', '.', $data['preco']);
        }

        [$ok, $res] = $this->repo->insert($data);
        if ($ok) {
            Flash::set('success', 'Procedimento cadastrado com sucesso.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        Flash::set('error', (string)$res);
        header('Location: ' . BASE_URL . '/procedimentos');
        exit;
    }

    /** GET /procedimentos/edit?id= */
    public function edit(Request $req): string
    {
        $id = (int)($req->query['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        $proc = $this->repo->find($id);
        if (!$proc) {
            Flash::set('error', 'Procedimento não encontrado.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        view('procedimentos/form', [
            'title'  => 'Editar Procedimento',
            'base'   => BASE_URL,
            'proc'   => $proc,
            'errors' => [],
            'isEdit' => true,
        ]);

        return '';
    }

    /** POST /procedimentos/update */
    public function update(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        $id = (int)($req->post['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        $data = [
            'nome'            => trim((string)$req->post['nome'] ?? ''),
            'preco'           => trim((string)$req->post['preco'] ?? ''),
            'duracao_minutos' => trim((string)$req->post['duracao_minutos'] ?? ''),
            'descricao'       => trim((string)$req->post['descricao'] ?? ''),
        ];

        $errors = [];
        if ($data['nome'] === '') {
            $errors['nome'] = 'Nome é obrigatório.';
        }
        if ($data['preco'] !== '' && !is_numeric(str_replace([','], ['.'], $data['preco']))) {
            $errors['preco'] = 'Preço inválido.';
        }
        if ($data['duracao_minutos'] !== '' && !ctype_digit($data['duracao_minutos'])) {
            $errors['duracao_minutos'] = 'Duração deve ser um número inteiro em minutos.';
        }

        if ($errors) {
            view('procedimentos/form', [
                'title'  => 'Editar Procedimento',
                'base'   => BASE_URL,
                'proc'   => $data + ['id' => $id],
                'errors' => $errors,
                'isEdit' => true,
            ]);
            return '';
        }

        if ($data['preco'] !== '') {
            $data['preco'] = str_replace(',', '.', $data['preco']);
        }

        [$ok, $res] = $this->repo->update($id, $data);
        if ($ok) {
            Flash::set('success', 'Procedimento atualizado com sucesso.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        Flash::set('error', (string)$res);
        header('Location: ' . BASE_URL . '/procedimentos');
        exit;
    }

    /** POST /procedimentos/delete */
    public function delete(Request $req): string
    {
        if (!Csrf::validate((string)($req->post['_csrf'] ?? ''))) {
            Flash::set('error', 'Falha de segurança (CSRF). Tente novamente.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        $id = (int)($req->post['id'] ?? 0);
        if ($id <= 0) {
            Flash::set('error', 'ID inválido.');
            header('Location: ' . BASE_URL . '/procedimentos');
            exit;
        }

        [$ok, $res] = $this->repo->delete($id);
        if ($ok) {
            Flash::set('success', 'Procedimento excluído com sucesso.');
        } else {
            Flash::set('error', (string)$res);
        }

        header('Location: ' . BASE_URL . '/procedimentos');
        exit;
    }

    /** (Opcional) GET /procedimentos/export */
    public function export(Request $req): string
    {
        require_once APP_PATH . '/Core/Csv.php';

        $q    = isset($req->query['q']) ? trim((string)$req->query['q']) : '';
        $sort = (string)($req->query['sort'] ?? 'created_at');
        $dir  = (string)($req->query['dir']  ?? 'desc');

        $rows = $this->repo->listFiltered($q, $sort, $dir);

        $headers = ['ID', 'Nome', 'Preço', 'Duração (min)', 'Descrição', 'Criado em'];
        $data = array_map(function (array $r) {
            return [
                'id'              => $r['id'],
                'nome'            => $r['nome'],
                'preco'           => $r['preco'],
                'duracao_minutos' => $r['duracao_minutos'],
                'descricao'       => $r['descricao'],
                'criado_em'       => $r['created_at'],
            ];
        }, $rows);

        \App\Core\Csv::download('procedimentos_' . date('Y-m-d_H-i-s') . '.csv', $headers, $data);
        return '';
    }
}
