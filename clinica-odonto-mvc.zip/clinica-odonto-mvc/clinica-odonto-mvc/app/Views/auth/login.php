<?php
$base  = BASE_URL ?: '';
$title = $title ?? 'Entrar';
$msg   = $msg   ?? '';
$err   = $err   ?? '';
$email = $email ?? '';
?>
<section class="card" style="max-width:720px;margin:auto">
  <h1><?= e($title) ?></h1>

  <?php if ($msg): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="alert danger"><?= e($err) ?></div><?php endif; ?>

  <form method="post" action="<?= e($base . '/login') ?>">
    <?= csrf_field() ?>

    <div class="form-group">
      <label for="email">E-mail</label>
      <input id="email" type="email" name="email" value="<?= e($email) ?>" required>
    </div>

    <div class="form-group">
      <label for="password">Senha</label>
      <input id="password" type="password" name="password" required>
    </div>

    <button class="btn" type="submit">Entrar</button>
  </form>
</section>
