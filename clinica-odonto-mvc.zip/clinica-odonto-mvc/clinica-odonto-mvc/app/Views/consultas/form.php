<?php
// Esperado pelo form:
// $title (string)
// $consulta (array) com chaves: id, paciente_id, dentista_id, procedimento_id, status, data_hora, valor_cobrado
// $pacientes (array de ['id','nome']), $dentistas (array de ['id','nome']), $procedimentos (array de ['id','nome'])
// $errors (array), $isEdit (bool)

// Defaults seguros
$base      = BASE_URL ?? '';
$consulta  = $consulta ?? [
    'id'               => null,
    'paciente_id'      => '',
    'dentista_id'      => '',
    'procedimento_id'  => '',
    'status'           => 'agendada',
    'data_hora'        => '',
    'valor_cobrado'    => '',
];
$pacientes      = is_array($pacientes ?? null) ? $pacientes : [];
$dentistas      = is_array($dentistas ?? null) ? $dentistas : [];
$procedimentos  = is_array($procedimentos ?? null) ? $procedimentos : [];
$errors         = is_array($errors ?? null) ? $errors : [];
$isEdit         = isset($isEdit) ? (bool)$isEdit : (!empty($consulta['id']));

// Normaliza valor do campo datetime-local
// Se vier "2025-10-12 21:02:00", converte para "2025-10-12T21:02"
if (!empty($consulta['data_hora'])) {
    $ts = strtotime((string)$consulta['data_hora']);
    if ($ts !== false) {
        $consulta['data_hora'] = date('Y-m-d\TH:i', $ts);
    }
}

// Normaliza valor_cobrado para string
$valor = (string)($consulta['valor_cobrado'] ?? '');
?>
<section class="card">
  <h1><?= e($title ?? 'Consulta') ?></h1>

  <?php if (!empty($errors['_global'])): ?>
    <div class="alert danger"><?= e($errors['_global']) ?></div>
  <?php endif; ?>

  <form method="post" action="<?= e($base . ($isEdit ? '/consultas/update' : '/consultas/store')) ?>">
    <?php
      if (function_exists('csrf_field')) {
          echo csrf_field();
      } else {
          echo '<input type="hidden" name="_csrf" value="">';
      }
    ?>

    <?php if ($isEdit): ?>
      <input type="hidden" name="id" value="<?= e((string)$consulta['id']) ?>">
    <?php endif; ?>

    <div class="grid-2">
      <div>
        <label>Paciente *</label>
        <select name="paciente_id" required>
          <option value="">Selecione…</option>
          <?php foreach ($pacientes as $p): ?>
            <option value="<?= e((string)$p['id']) ?>"
              <?= (string)$consulta['paciente_id'] === (string)$p['id'] ? 'selected' : '' ?>>
              <?= e((string)$p['nome']) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <?php if (!empty($errors['paciente_id'])): ?><div class="error"><?= e($errors['paciente_id']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Dentista *</label>
        <select name="dentista_id" required>
          <option value="">Selecione…</option>
          <?php foreach ($dentistas as $d): ?>
            <option value="<?= e((string)$d['id']) ?>"
              <?= (string)$consulta['dentista_id'] === (string)$d['id'] ? 'selected' : '' ?>>
              <?= e((string)$d['nome']) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <?php if (!empty($errors['dentista_id'])): ?><div class="error"><?= e($errors['dentista_id']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Procedimento *</label>
        <select name="procedimento_id" required>
          <option value="">Selecione…</option>
          <?php foreach ($procedimentos as $proc): ?>
            <option value="<?= e((string)$proc['id']) ?>"
              <?= (string)$consulta['procedimento_id'] === (string)$proc['id'] ? 'selected' : '' ?>>
              <?= e((string)$proc['nome']) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <?php if (!empty($errors['procedimento_id'])): ?><div class="error"><?= e($errors['procedimento_id']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Status *</label>
        <?php
          $optsStatus = [
            'agendada' => 'Agendada',
            'confirmada' => 'Confirmada',
            'realizada' => 'Realizada',
            'cancelada' => 'Cancelada',
          ];
          $statusAtual = (string)($consulta['status'] ?? 'agendada');
        ?>
        <select name="status" required>
          <?php foreach ($optsStatus as $val => $label): ?>
            <option value="<?= e($val) ?>" <?= $statusAtual === $val ? 'selected' : '' ?>>
              <?= e($label) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <?php if (!empty($errors['status'])): ?><div class="error"><?= e($errors['status']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Data/Hora *</label>
        <input type="datetime-local" name="data_hora"
               value="<?= e((string)$consulta['data_hora']) ?>" required>
        <?php if (!empty($errors['data_hora'])): ?><div class="error"><?= e($errors['data_hora']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Valor cobrado</label>
        <input type="text" name="valor_cobrado" value="<?= e($valor) ?>">
        <?php if (!empty($errors['valor_cobrado'])): ?><div class="error"><?= e($errors['valor_cobrado']) ?></div><?php endif; ?>
      </div>
    </div>

    <div style="margin-top:12px; display:flex; gap:8px;">
      <button type="submit"><?= $isEdit ? 'Salvar alterações' : 'Cadastrar' ?></button>
      <a class="btn" href="<?= e($base . '/consultas') ?>">Voltar</a>
    </div>
  </form>
</section>
