<?php
$base = BASE_URL ?: '';
$user = $_SESSION['user'] ?? null;
?><!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title><?= e($title ?? 'Clínica Odonto MVC') ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?= e(asset('assets/css/style.css')) ?>">
</head>
<body>
  <header class="site-header">
    <div class="container" style="display:flex;gap:16px;align-items:center;justify-content:space-between;">
      <strong>Clínica Odonto MVC</strong>
      <nav style="display:flex;gap:12px">
        <a href="<?= e($base . '/pacientes') ?>">Pacientes</a>
        <a href="<?= e($base . '/dentistas') ?>">Dentistas</a>
        <a href="<?= e($base . '/procedimentos') ?>">Procedimentos</a>
        <a href="<?= e($base . '/consultas') ?>">Consultas</a>
      </nav>
      <div>
        <?php if ($user): ?>
          <span>Olá, <?= e($user['name'] ?? $user['email']) ?></span>
          <form method="post" action="<?= e($base . '/logout') ?>" style="display:inline;margin-left:8px">
            <?= csrf_field() ?>
            <button class="btn-sm" type="submit">Sair</button>
          </form>
        <?php else: ?>
          <a class="btn-sm" href="<?= e($base . '/login') ?>">Entrar</a>
        <?php endif; ?>
      </div>
    </div>
  </header>

  <main class="container" style="padding:16px">
    <?php
      if (!empty($viewFile) && is_file($viewFile)) {
          require $viewFile;
      } elseif (isset($content)) {
          echo $content;
      } else {
          echo '<p>View não encontrada.</p>';
      }
    ?>
  </main>

  <footer class="site-footer">
    <div class="container"><small>© <?= date('Y') ?> Clínica Odonto — MVC PHP</small></div>
  </footer>
</body>
</html>
