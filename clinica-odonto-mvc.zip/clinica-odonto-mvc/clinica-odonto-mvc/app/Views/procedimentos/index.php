<?php
/** @var string $q */
/** @var int $page */
/** @var string $sort */
/** @var string $dir */
/** @var array $items */
/** @var int $total */
/** @var int $totalPages */

$q         = isset($q)    ? (string)$q    : '';
$page      = isset($page) ? (int)$page    : 1;
$sort      = isset($sort) ? (string)$sort : 'created_at';
$dir       = isset($dir)  ? (string)$dir  : 'desc';
$items     = isset($items) && is_array($items) ? $items : [];
$total     = isset($total) ? (int)$total : 0;
$totalPages= isset($totalPages) ? (int)$totalPages : 1;

$base = BASE_URL ?: '';

$qsBase = function(array $extra = []) use ($q, $page, $sort, $dir): string {
    $params = ['q'=>$q,'page'=>$page,'sort'=>$sort,'dir'=>$dir] + $extra;
    $params = array_filter($params, fn($v)=>$v!==null && $v!=='');
    return '?' . http_build_query($params);
};
$toggleDir = function(string $col) use ($sort, $dir): string {
    return ($sort === $col && strtolower($dir)==='asc') ? 'desc' : 'asc';
};

$msg = $_GET['msg'] ?? '';
$err = $_GET['err'] ?? '';
?>
<section class="card">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
    <h1>Procedimentos</h1>
    <a class="btn" href="<?= e($base . '/procedimentos/create') ?>">+ Novo</a>
  </div>

  <?php if ($msg): ?><div class="alert success"><?= e($msg) ?></div><?php endif; ?>
  <?php if ($err): ?><div class="alert danger"><?= e($err) ?></div><?php endif; ?>

  <form method="get" action="<?= e($base . '/procedimentos') ?>" class="form-inline" style="margin:8px 0">
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="Buscar por nome ou descrição">
    <button type="submit">Buscar</button>
    <?php if ($q!==''): ?>
      <a href="<?= e($base . '/procedimentos') ?>" class="link">Limpar</a>
    <?php endif; ?>
  </form>

  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th><a href="<?= e($base . '/procedimentos' . $qsBase(['sort'=>'nome',        'dir'=>$toggleDir('nome'),        'page'=>1])) ?>">Nome</a></th>
          <th>Descrição</th>
          <th><a href="<?= e($base . '/procedimentos' . $qsBase(['sort'=>'preco',       'dir'=>$toggleDir('preco'),       'page'=>1])) ?>">Preço</a></th>
          <th><a href="<?= e($base . '/procedimentos' . $qsBase(['sort'=>'duracao_min', 'dir'=>$toggleDir('duracao_min'), 'page'=>1])) ?>">Duração (min)</a></th>
          <th><a href="<?= e($base . '/procedimentos' . $qsBase(['sort'=>'created_at',  'dir'=>$toggleDir('created_at'),  'page'=>1])) ?>">Criado em</a></th>
          <th style="width:150px">Ações</th>
        </tr>
      </thead>
      <tbody>
      <?php if(!$items): ?>
        <tr><td colspan="6">Nenhum registro encontrado.</td></tr>
      <?php else: foreach($items as $row): ?>
        <tr>
          <td><?= e($row['nome']) ?></td>
          <td><?= e($row['descricao'] ?? '') ?></td>
          <td><?= e(number_format((float)$row['preco'], 2, ',', '.')) ?></td>
          <td><?= e((string)($row['duracao_min'] ?? '')) ?></td>
          <td><?= e($row['created_at']) ?></td>
          <td class="actions">
            <a class="btn-sm" href="<?= e($base . '/procedimentos/edit?id='.(int)$row['id']) ?>">Editar</a>
            <form method="post" action="<?= e($base . '/procedimentos/delete') ?>" onsubmit="return confirm('Excluir este procedimento?');" style="display:inline">
              <input type="hidden" name="id" value="<?= e((string)$row['id']) ?>">
              <button type="submit" class="btn-sm danger">Excluir</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>

  <?php if($totalPages>1): ?>
    <nav class="pagination">
      <?php for($p=1;$p<=$totalPages;$p++): ?>
        <?php if($p==$page): ?>
          <span class="page current"><?= $p ?></span>
        <?php else: ?>
          <a class="page" href="<?= e($base . '/procedimentos' . $qsBase(['page'=>$p])) ?>"><?= $p ?></a>
        <?php endif; ?>
      <?php endfor; ?>
    </nav>
  <?php endif; ?>

  <p style="margin-top:8px"><small>Total: <?= (int)$total ?> registro(s)</small></p>
</section>
