<?php
// Espera: $title, $proc, $errors, $isEdit
$base   = BASE_URL ?: '';
$proc   = $proc   ?? ['id'=>null,'nome'=>'','preco'=>'','duracao_minutos'=>'','descricao'=>''];
$errors = $errors ?? [];
$isEdit = isset($isEdit) ? (bool)$isEdit : (!empty($proc['id']));

// Normaliza valor da duração para aceitar tanto 'duracao_minutos' quanto 'duracao'
$duracaoVal = $proc['duracao_minutos'] ?? ($proc['duracao'] ?? '');

// (opcional) normaliza preço se vier nulo
$precoVal = (string)($proc['preco'] ?? '');
?>
<section class="card">
  <h1><?= e($title ?? 'Procedimento') ?></h1>

  <?php if (!empty($errors['_global'])): ?>
    <div class="alert danger"><?= e($errors['_global']) ?></div>
  <?php endif; ?>

  <form method="post" action="<?= e($base . ($isEdit ? '/procedimentos/update' : '/procedimentos/store')) ?>">
    <?php
      if (function_exists('csrf_field')) {
          echo csrf_field();
      } else {
          echo '<input type="hidden" name="_csrf" value="">';
      }
    ?>

    <?php if ($isEdit): ?>
      <input type="hidden" name="id" value="<?= e((string)$proc['id']) ?>">
    <?php endif; ?>

    <div class="grid-2">
      <div>
        <label>Nome *</label>
        <input type="text" name="nome" value="<?= e((string)$proc['nome']) ?>" required>
        <?php if (!empty($errors['nome'])): ?><div class="error"><?= e($errors['nome']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Preço *</label>
        <input type="text" name="preco" value="<?= e($precoVal) ?>" required>
        <?php if (!empty($errors['preco'])): ?><div class="error"><?= e($errors['preco']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Duração (minutos)</label>
        <input type="text" name="duracao_minutos" value="<?= e($duracaoVal) ?>">
        <?php if (!empty($errors['duracao_minutos'])): ?><div class="error"><?= e($errors['duracao_minutos']) ?></div><?php endif; ?>
      </div>

      <div>
        <label>Descrição</label>
        <input type="text" name="descricao" value="<?= e((string)$proc['descricao']) ?>">
        <?php if (!empty($errors['descricao'])): ?><div class="error"><?= e($errors['descricao']) ?></div><?php endif; ?>
      </div>
    </div>

    <div style="margin-top:12px; display:flex; gap:8px;">
      <button type="submit"><?= $isEdit ? 'Salvar alterações' : 'Cadastrar' ?></button>
      <a class="btn" href="<?= e($base . '/procedimentos') ?>">Voltar</a>
    </div>
  </form>
</section>
