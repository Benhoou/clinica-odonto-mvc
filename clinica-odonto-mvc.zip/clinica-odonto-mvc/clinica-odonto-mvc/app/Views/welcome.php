<?php
// Helper de escape simples para a View (sanitize/escape)
if (!function_exists('e')) {
    function e($v): string {
        return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Clínica Odonto MVC — Passo 0</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/clinica-odonto-mvc/public/assets/css/styles.css">
</head>
<body>
  <main class="container">
    <h1>Clínica Odonto MVC</h1>
    <p>Passo 0 concluído com sucesso ✅</p>

    <section class="card">
      <h2>Status inicial</h2>
      <ul>
        <li><?= e($message ?? '') ?></li>
        <li>PHP: <?= e($env['php_version'] ?? '') ?></li>
      </ul>
    </section>

    <section class="card">
      <h2>Ambiente</h2>
      <ul>
        <li>BASE_PATH: <?= e($env['base_path'] ?? '') ?></li>
        <li>APP_PATH: <?= e($env['app_path'] ?? '') ?></li>
        <li>DOCUMENT_ROOT: <?= e($env['document_root'] ?? '') ?></li>
        <li>REQUEST_URI: <?= e($env['request_uri'] ?? '') ?></li>
      </ul>
    </section>

    <section class="card">
      <h2>Teste de rewrite</h2>
      <p>
        Clique para testar URL amigável (sem arquivo físico):
        <a href="/clinica-odonto-mvc/public/teste-rewrite">/teste-rewrite</a>
        <br>Você deve continuar vendo esta mesma página.
      </p>
    </section>

    <footer>
      <small>Pronto para o Passo 1: Router e DB.</small>
    </footer>
  </main>
</body>
</html>
