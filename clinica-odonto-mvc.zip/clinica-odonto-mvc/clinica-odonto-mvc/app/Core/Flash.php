<?php
declare(strict_types=1);

namespace App\Core;

final class Flash
{
    private const KEY = '__flash__';

    public static function set(string $type, string $message): void
    {
        $_SESSION[self::KEY][$type] = $message;
    }

    public static function get(string $type, string $default = ''): string
    {
        return (string)($_SESSION[self::KEY][$type] ?? $default);
    }

    public static function pull(string $type, string $default = ''): string
    {
        $msg = (string)($_SESSION[self::KEY][$type] ?? $default);
        unset($_SESSION[self::KEY][$type]);
        if (empty($_SESSION[self::KEY])) unset($_SESSION[self::KEY]);
        return $msg;
    }

    public static function clear(?string $type = null): void
    {
        if ($type === null) {
            unset($_SESSION[self::KEY]);
            return;
        }
        unset($_SESSION[self::KEY][$type]);
        if (empty($_SESSION[self::KEY])) unset($_SESSION[self::KEY]);
    }
}
