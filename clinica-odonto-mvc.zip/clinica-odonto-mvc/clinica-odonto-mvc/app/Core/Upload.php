<?php
declare(strict_types=1);

namespace App\Core;

final class Upload
{
    public const MAX_BYTES = 2 * 1024 * 1024; // 2MB
    public const ALLOWED   = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'application/pdf' => 'pdf',
    ];

    public static function process(?array $file, string $destDir, string $baseUrlRel = 'uploads'): array
    {
        // retorna ['ok'=>bool, 'path'=>string|null, 'err'=>string|null]
        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return ['ok'=>true, 'path'=>null, 'err'=>null];
        }

        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            return ['ok'=>false, 'path'=>null, 'err'=>'Falha no upload.'];
        }

        if (($file['size'] ?? 0) > self::MAX_BYTES) {
            return ['ok'=>false, 'path'=>null, 'err'=>'Arquivo maior que 2MB.'];
        }

        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime  = $finfo->file($file['tmp_name']);
        if (!isset(self::ALLOWED[$mime])) {
            return ['ok'=>false, 'path'=>null, 'err'=>'Tipo não permitido (apenas JPG, PNG ou PDF).'];
        }

        $ext   = self::ALLOWED[$mime];
        $name  = uniqid('anx_', true) . '.' . $ext;

        $destAbs = rtrim(PUBLIC_PATH, '/') . '/uploads/' . $name;
        if (!is_dir(rtrim(PUBLIC_PATH, '/') . '/uploads')) {
            mkdir(rtrim(PUBLIC_PATH, '/') . '/uploads', 0775, true);
        }

        if (!move_uploaded_file($file['tmp_name'], $destAbs)) {
            return ['ok'=>false, 'path'=>null, 'err'=>'Não foi possível salvar o arquivo.'];
        }

        return ['ok'=>true, 'path'=> $baseUrlRel . '/' . $name, 'err'=>null];
    }

    public static function remove(?string $rel): void
    {
        if (!$rel) return;
        $abs = rtrim(PUBLIC_PATH, '/') . '/' . ltrim($rel, '/');
        if (is_file($abs)) {
            @unlink($abs);
        }
    }
}
