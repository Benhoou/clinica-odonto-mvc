-- ============================================================
-- Clínica Odonto — Estrutura de Banco + Seeds
-- Compatível MySQL 8.x (utf8mb4)
-- ============================================================

-- Cria o banco (se não existir) e seleciona
CREATE DATABASE IF NOT EXISTS clinica_odonto
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE clinica_odonto;

-- Segurança: desligar FKs para recriar as tabelas com segurança
SET FOREIGN_KEY_CHECKS = 0;

-- Drop na ordem inversa das dependências
DROP TABLE IF EXISTS consultas;
DROP TABLE IF EXISTS procedimentos;
DROP TABLE IF EXISTS dentistas;
DROP TABLE IF EXISTS pacientes;

-- (Opcional, para passos futuros)
DROP TABLE IF EXISTS usuarios;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Tabela: pacientes
-- ============================================================
CREATE TABLE pacientes (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome            VARCHAR(120)          NOT NULL,
  email           VARCHAR(160)          NULL,
  telefone        VARCHAR(30)           NULL,
  data_nascimento DATE                  NULL,
  cpf             VARCHAR(14)           NULL, -- 000.000.000-00
  endereco        VARCHAR(200)          NULL,
  observacoes     TEXT                  NULL,
  created_at      DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT uk_pacientes_email UNIQUE (email),
  CONSTRAINT uk_pacientes_cpf   UNIQUE (cpf)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Tabela: dentistas
-- ============================================================
CREATE TABLE dentistas (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(120)          NOT NULL,
  email         VARCHAR(160)          NULL,
  telefone      VARCHAR(30)           NULL,
  cro           VARCHAR(30)           NULL, -- registro profissional
  especialidade VARCHAR(100)          NULL,
  created_at    DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT uk_dentistas_email UNIQUE (email),
  CONSTRAINT uk_dentistas_cro   UNIQUE (cro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Tabela: procedimentos
-- ============================================================
CREATE TABLE procedimentos (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(120)          NOT NULL,
  descricao     VARCHAR(240)          NULL,
  preco         DECIMAL(10,2)         NOT NULL DEFAULT 0.00,
  duracao_min   INT                   NULL, -- duração sugerida
  created_at    DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME              NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT uk_procedimentos_nome UNIQUE (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Tabela: consultas (relaciona Paciente, Dentista, Procedimento)
-- ============================================================
CREATE TABLE consultas (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  paciente_id      INT UNSIGNED       NOT NULL,
  dentista_id      INT UNSIGNED       NOT NULL,
  procedimento_id  INT UNSIGNED       NOT NULL,
  data_hora        DATETIME           NOT NULL,
  status           ENUM('agendada','confirmada','realizada','cancelada') NOT NULL DEFAULT 'agendada',
  observacoes      TEXT               NULL,
  valor_cobrado    DECIMAL(10,2)      NULL,
  created_at       DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_consultas_paciente
    FOREIGN KEY (paciente_id) REFERENCES pacientes(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_consultas_dentista
    FOREIGN KEY (dentista_id) REFERENCES dentistas(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_consultas_procedimento
    FOREIGN KEY (procedimento_id) REFERENCES procedimentos(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  INDEX idx_consultas_data_hora (data_hora),
  INDEX idx_consultas_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- (Opcional) Tabela: usuarios (para login/logout no passo futuro)
-- ============================================================
CREATE TABLE usuarios (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(120)     NOT NULL,
  email         VARCHAR(160)     NOT NULL,
  senha_hash    VARCHAR(255)     NOT NULL,
  role          ENUM('admin','atendente') NOT NULL DEFAULT 'atendente',
  created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT uk_usuarios_email UNIQUE (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEEDS (dados de exemplo)
-- ============================================================

-- Pacientes
INSERT INTO pacientes (nome, email, telefone, data_nascimento, cpf, endereco, observacoes) VALUES
('Ana Silva',     'ana.silva@example.com',     '(51) 99999-1111', '1992-05-10', '111.222.333-44', 'Rua Um, 123',  NULL),
('Bruno Souza',   'bruno.souza@example.com',   '(51) 98888-2222', '1988-11-22', '222.333.444-55', 'Rua Dois, 456', 'Alergia a analgésico comum'),
('Carla Mendes',  'carla.mendes@example.com',  '(51) 97777-3333', '1998-01-30', '333.444.555-66', 'Av. Três, 789', NULL);

-- Dentistas
INSERT INTO dentistas (nome, email, telefone, cro, especialidade) VALUES
('Dra. Fernanda Lima', 'fernanda.lima@odonto.com', '(51) 93456-0001', 'CRO-RS 12345', 'Ortodontia'),
('Dr. Gustavo Reis',   'gustavo.reis@odonto.com',  '(51) 93456-0002', 'CRO-RS 67890', 'Implantodontia');

-- Procedimentos
INSERT INTO procedimentos (nome, descricao, preco, duracao_min) VALUES
('Limpeza',       'Profilaxia completa',              150.00, 40),
('Restauração',   'Restauração em resina composta',   250.00, 60),
('Clareamento',   'Clareamento dental consultório',   900.00, 90);

-- Consultas (datas de exemplo próximas do presente)
INSERT INTO consultas (paciente_id, dentista_id, procedimento_id, data_hora, status, observacoes, valor_cobrado) VALUES
(1, 1, 1, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 1 DAY), 'agendada', 'Primeira avaliação', 150.00),
(2, 2, 2, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 2 DAY), 'confirmada', NULL, 250.00),
(3, 1, 3, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 3 DAY), 'agendada', 'Paciente ansiosa', 900.00);

-- Usuário admin padrão (senha: admin123 — troque depois)
-- Use uma hash gerada por password_hash('admin123', PASSWORD_DEFAULT)
INSERT INTO usuarios (nome, email, senha_hash, role) VALUES
('Administrador', 'admin@clinica.local', '$2y$10$2d3sE6O0OaA1m7mSxUTf1uVg0Qq3Q4GQ0qF4n3L1o9b9n8QH0m7uK', 'admin');

-- Índices adicionais
CREATE INDEX idx_pacientes_nome ON pacientes (nome);
CREATE INDEX idx_dentistas_nome ON dentistas (nome);
CREATE INDEX idx_procedimentos_preco ON procedimentos (preco);

-- Fim
