-- Tabela de usuários
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Usuário admin (senha: 123456)
INSERT INTO users (name, email, password_hash) VALUES
('Administrador', 'admin@local', '$2y$10$0mZt9sYc6QmOHGgZbKcILeh4F5a7u7QYBv5K2FQO2bQyJf5c4wQhK');
-- Observação: hash gerado por password_hash('123456', PASSWORD_DEFAULT) em PHP 8
